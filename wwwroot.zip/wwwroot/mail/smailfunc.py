import requests
import json
import logging

def mailtofunc( amaillist ):
    amaillist_list = amaillist.split(";")
    amaillist_dict_list = []
    for mail_to_tem in amaillist_list:
        amaillist_dict_tmp = {}
        tmp_dict = {}
        tmp_dict["address"] = mail_to_tem
        amaillist_dict_tmp["emailAddress"] = tmp_dict
        amaillist_dict_list.append(amaillist_dict_tmp)
    return amaillist_dict_list

def fsendnamail( to_mail_address,mail_subject,mail_content,attachment ):
    url = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/v2.0/token"
    payload = "client_id=0ba36ee4-3758-429b-94e9-23475626b55c&scope=offline_access%20user.read%20mail.read%20mail.send%20mail.readwrite&refresh_token=OAQABAAAAAABeAFzDwllzTYGDLh_qYbH8e70FOMh-Gg2QmIs10Xty8SQcGJ6UyyNvsXW32PMB-IY6dgioAp7ZXZLzGimN3IkJSU8vsb8TnT7ZHsF4Ee0QTZEjzrQivpX096XJZ40ePmZEVW00YRJdjbgaH4wWzcKLVSQ86N0MwxxnvnzwFAT7M6VYPfBkgZ7R3cLXkmlI5YPOCOC-xmVbN-RxP48X2NxtgbvAXMYBPHU1OfajNs7K-QpKpwUTl7QIseRgIB8wY0N5ACF8NsczyQ6XhCtRRFaMQHmBqv1Us5vsao9YASChm_nF17c9lcgyrY_KHP1eEjUqmqUXasV4NYD1nbM4mxyGi6BGFpTQKrv5dvWZ445e97fFXQrTr_pJ26hf_PtLNoTs41FrNGUpJcXs2chTiMJPD3eWABq378Qp7qryqOaou-RZJSEj4y8E850RKu_6_zj8-QgDyt_eyqVY01Qn2CL-_ovTHNNnMhMb0B7q-XJBmU6TI4JOiUGZML9t1ewTebUBvIT7dA2vdQgXi0UGi6dnuaYAohvxK2XmQEEXXRZCZUgH0XvKLwUrjtn2KTDEPsjWBenWpsO8Lo_NaR_hgp_5jWY6q6JOrsq9mdlBYNf1yZLr8QqftMMm9TvQX8TKbm_prRu6TSBDLI7GPD3itRYLDjSAU0oC7ix57adRyvrwdpYqNv1fQ6v9Bc1VHDQwoBC2uzIbAcxTov1rUIjmSwTjylrCFVi7f9ccJJzVwg1Hv5FpS3DKOTd7-KZLoLWm-YUUvg9xrmfOE7L1cRIwQXKkjW8Dh69XxVkm53a4qAje_LS5XV-6bIi6785II5TBk3Sw_9-LHBroNRIycg2CRWIr-ejETBvDm9QNHaGR_uBNSsNNL1RHgrRQhZCEjbiRgagPe9VmbU2nuWmZEZK0omcmIAA&redirect_uri=http%3A%2F%2Flocalhost%3A8080&grant_type=refresh_token&client_secret=Y6f5ba3XhY%3DGpVc%5B.P8O%3F4xdyYJ1Arcq"
    headers = {	'Content-Type': "application/x-www-form-urlencoded" }
    response = requests.request("POST", url, data=payload, headers=headers)
    token_dict = json.loads(response.text)
    mailto = mailtofunc(to_mail_address)
    url_sm = "https://graph.microsoft.com/v1.0/users/b7ed64c8-2f97-4588-913a-7f60fabad6b9/sendmail"
    payload_sm_1 = {"message": {"subject": mail_subject,"body": {"contentType": "HTML","content": mail_content},"toRecipients": mailto, "attachments":attachment}}

    payload_sm = json.dumps(payload_sm_1)

    token_sm = "Bearer " +  token_dict["access_token"]
    headers_sm = {
        'Authorization': token_sm,
        'Content-Type': "application/json"
        }

    response = requests.request("POST", url_sm, data=payload_sm, headers=headers_sm)
    logging.info("mail send response status: " + str(response.status_code))



def fsendamail( to_mail_address,mail_subject,mail_content,fileName_data,fileName_name ):
    url = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/v2.0/token"
    payload = "client_id=0ba36ee4-3758-429b-94e9-23475626b55c&scope=offline_access%20user.read%20mail.read%20mail.send%20mail.readwrite&refresh_token=OAQABAAAAAABeAFzDwllzTYGDLh_qYbH8e70FOMh-Gg2QmIs10Xty8SQcGJ6UyyNvsXW32PMB-IY6dgioAp7ZXZLzGimN3IkJSU8vsb8TnT7ZHsF4Ee0QTZEjzrQivpX096XJZ40ePmZEVW00YRJdjbgaH4wWzcKLVSQ86N0MwxxnvnzwFAT7M6VYPfBkgZ7R3cLXkmlI5YPOCOC-xmVbN-RxP48X2NxtgbvAXMYBPHU1OfajNs7K-QpKpwUTl7QIseRgIB8wY0N5ACF8NsczyQ6XhCtRRFaMQHmBqv1Us5vsao9YASChm_nF17c9lcgyrY_KHP1eEjUqmqUXasV4NYD1nbM4mxyGi6BGFpTQKrv5dvWZ445e97fFXQrTr_pJ26hf_PtLNoTs41FrNGUpJcXs2chTiMJPD3eWABq378Qp7qryqOaou-RZJSEj4y8E850RKu_6_zj8-QgDyt_eyqVY01Qn2CL-_ovTHNNnMhMb0B7q-XJBmU6TI4JOiUGZML9t1ewTebUBvIT7dA2vdQgXi0UGi6dnuaYAohvxK2XmQEEXXRZCZUgH0XvKLwUrjtn2KTDEPsjWBenWpsO8Lo_NaR_hgp_5jWY6q6JOrsq9mdlBYNf1yZLr8QqftMMm9TvQX8TKbm_prRu6TSBDLI7GPD3itRYLDjSAU0oC7ix57adRyvrwdpYqNv1fQ6v9Bc1VHDQwoBC2uzIbAcxTov1rUIjmSwTjylrCFVi7f9ccJJzVwg1Hv5FpS3DKOTd7-KZLoLWm-YUUvg9xrmfOE7L1cRIwQXKkjW8Dh69XxVkm53a4qAje_LS5XV-6bIi6785II5TBk3Sw_9-LHBroNRIycg2CRWIr-ejETBvDm9QNHaGR_uBNSsNNL1RHgrRQhZCEjbiRgagPe9VmbU2nuWmZEZK0omcmIAA&redirect_uri=http%3A%2F%2Flocalhost%3A8080&grant_type=refresh_token&client_secret=Y6f5ba3XhY%3DGpVc%5B.P8O%3F4xdyYJ1Arcq"
    headers = {	'Content-Type': "application/x-www-form-urlencoded" }
    response = requests.request("POST", url, data=payload, headers=headers)
    token_dict = json.loads(response.text)
    mailto = mailtofunc(to_mail_address)
    url_sm = "https://graph.microsoft.com/v1.0/users/b7ed64c8-2f97-4588-913a-7f60fabad6b9/sendmail"
    payload_sm_1 = {"message": {"subject": mail_subject,"body": {"contentType": "HTML","content": mail_content},"toRecipients": mailto, "attachments":[{"@odata.type":"#Microsoft.OutlookServices.FileAttachment","name":fileName_name,"contentBytes":fileName_data}]}}

    payload_sm = json.dumps(payload_sm_1)

    token_sm = "Bearer " +  token_dict["access_token"]
    headers_sm = {
        'Authorization': token_sm,
        'Content-Type': "application/json"
        }

    response = requests.request("POST", url_sm, data=payload_sm, headers=headers_sm)
    logging.info("mail send response status: " + str(response.status_code))
    logging.info(mail_subject + "  has been sent with attachment " + fileName_name +" , please check")
    


def fsendmail( to_mail_address,mail_subject,mail_content ):
    url = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/v2.0/token"
    payload = "client_id=0ba36ee4-3758-429b-94e9-23475626b55c&scope=offline_access%20user.read%20mail.read%20mail.send%20mail.readwrite&refresh_token=OAQABAAAAAABeAFzDwllzTYGDLh_qYbH8e70FOMh-Gg2QmIs10Xty8SQcGJ6UyyNvsXW32PMB-IY6dgioAp7ZXZLzGimN3IkJSU8vsb8TnT7ZHsF4Ee0QTZEjzrQivpX096XJZ40ePmZEVW00YRJdjbgaH4wWzcKLVSQ86N0MwxxnvnzwFAT7M6VYPfBkgZ7R3cLXkmlI5YPOCOC-xmVbN-RxP48X2NxtgbvAXMYBPHU1OfajNs7K-QpKpwUTl7QIseRgIB8wY0N5ACF8NsczyQ6XhCtRRFaMQHmBqv1Us5vsao9YASChm_nF17c9lcgyrY_KHP1eEjUqmqUXasV4NYD1nbM4mxyGi6BGFpTQKrv5dvWZ445e97fFXQrTr_pJ26hf_PtLNoTs41FrNGUpJcXs2chTiMJPD3eWABq378Qp7qryqOaou-RZJSEj4y8E850RKu_6_zj8-QgDyt_eyqVY01Qn2CL-_ovTHNNnMhMb0B7q-XJBmU6TI4JOiUGZML9t1ewTebUBvIT7dA2vdQgXi0UGi6dnuaYAohvxK2XmQEEXXRZCZUgH0XvKLwUrjtn2KTDEPsjWBenWpsO8Lo_NaR_hgp_5jWY6q6JOrsq9mdlBYNf1yZLr8QqftMMm9TvQX8TKbm_prRu6TSBDLI7GPD3itRYLDjSAU0oC7ix57adRyvrwdpYqNv1fQ6v9Bc1VHDQwoBC2uzIbAcxTov1rUIjmSwTjylrCFVi7f9ccJJzVwg1Hv5FpS3DKOTd7-KZLoLWm-YUUvg9xrmfOE7L1cRIwQXKkjW8Dh69XxVkm53a4qAje_LS5XV-6bIi6785II5TBk3Sw_9-LHBroNRIycg2CRWIr-ejETBvDm9QNHaGR_uBNSsNNL1RHgrRQhZCEjbiRgagPe9VmbU2nuWmZEZK0omcmIAA&redirect_uri=http%3A%2F%2Flocalhost%3A8080&grant_type=refresh_token&client_secret=Y6f5ba3XhY%3DGpVc%5B.P8O%3F4xdyYJ1Arcq"
    headers = {	'Content-Type': "application/x-www-form-urlencoded" }
    response = requests.request("POST", url, data=payload, headers=headers)
    token_dict = json.loads(response.text)
    mailto = mailtofunc(to_mail_address)
    url_sm = "https://graph.microsoft.com/v1.0/users/b7ed64c8-2f97-4588-913a-7f60fabad6b9/sendmail"
    payload_sm_1 = {"message": {"subject": mail_subject,"body": {"contentType": "HTML","content": mail_content},"toRecipients": mailto}}

    payload_sm = json.dumps(payload_sm_1)

    token_sm = "Bearer " +  token_dict["access_token"]
    headers_sm = {
        'Authorization': token_sm,
        'Content-Type': "application/json"
        }

    response = requests.request("POST", url_sm, data=payload_sm, headers=headers_sm)
    logging.info("mail send response status: " + str(response.status_code))
    logging.info(mail_subject + "  has been sent, please check")

