import requests
import json
import logging

def mailtofunc( amaillist ):
    amaillist_list = amaillist.split(";")
    amaillist_dict_list = []
    for mail_to_tem in amaillist_list:
        amaillist_dict_tmp = {}
        tmp_dict = {}
        tmp_dict["address"] = mail_to_tem
        amaillist_dict_tmp["emailAddress"] = tmp_dict
        amaillist_dict_list.append(amaillist_dict_tmp)
    return amaillist_dict_list

def fsendamail( to_mail_address,mail_subject,mail_content,fileName_data,fileName_name ):
    url = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/v2.0/token"
    payload = "client_id=0ba36ee4-3758-429b-94e9-23475626b55c&scope=mail.send%20mail.readwrite&refresh_token=OAQABAAAAAACQN9QBRU3jT6bcBQLZNUj7PZsd478_Q8wnqqQUsxY96lAnYqBUboga40sQC86KsvQdLyVUgVBHeIFv0kHBpD1eTu3jcrti20XBpG53_dOwPn4DJR5KO097U975BvrSyb3KF0rRrNBJr668cr6D5SDPQFJtBGBazLldzhMA9Lg7tdwxvoxwkc3eoN0nr_kPAwSMtyoo56x8leRHM1tth_Npm-pOe2yuvF8bJ3RL9lyrz5VN8iq8LOFrdjnytPu2W5IpWhMp2Ij-hkMsYCZ9O79Pz77lNspeCDHYL-4MJBxP7-U-w2AIkoRRasi-t6E1cRKKq6jLc2o2infnriYn4yNIKzMglrW57exfBK4SYSlPvH40_fWq5dqaNlm6V38_JAt8QnZBnhSNxrTAGkqrB03jrWp-S1xLZi_HQwWacvKeRugIpCFWnCuqSA-l_2dEBoPmFKvH02h8SpSRyoyVaQqAfMxbnEd4EqOmakYc9hbKSid9x1_bW4BiJEDnq_GZNZUbBeFFdBL4dvISckMrSwnCezc3sjpAmI_n8dsAUKrGlMm0tP0N99vlemw_0v4jAY_2iCkN8L2IvvOXHJyNOhQ8mmfy5qS9L4aRXlk1Mr2EYiRc04ZNwn-lALY_82IU0af4DFgOzEKCQ0c3pnleVzXmgz_k_pvanvJfh39h7F_YzTUt6AuN8ftmGH8kK0fzdSnLAlJEjed8u_RHpyg5lVJIqKOUE7Y1xVoz-UMoBCV4xL1kHvnkc2_p9C84ulw19cDN198i4RD8PF_5ylrEaGwfgI5ToRwjsETmZ0BFO-MkQvhcNY32oxaxa0CPcM1by_o-sBkyZCUt1wzSi6Cxa62wOuGeOjcZCPv3qGB-J3z2PILoSkdhJUENu8k0RLjFG_u6GndrvlDKPcLk7s50CBU3IAA&redirect_uri=http%3A%2F%2Flocalhost%3A8080&grant_type=refresh_token&client_secret=Y6f5ba3XhY%3DGpVc%5B.P8O%3F4xdyYJ1Arcq"
    headers = {	'Content-Type': "application/x-www-form-urlencoded" }
    response = requests.request("POST", url, data=payload, headers=headers)
    token_dict = json.loads(response.text)
    mailto = mailtofunc(to_mail_address)
    url_sm = "https://graph.microsoft.com/v1.0/users/b7ed64c8-2f97-4588-913a-7f60fabad6b9/sendmail"
    payload_sm_1 = {"message": {"subject": mail_subject,"body": {"contentType": "HTML","content": mail_content},"toRecipients": mailto, "attachments":[{"@odata.type":"#Microsoft.OutlookServices.FileAttachment","name":fileName_name,"contentBytes":fileName_data}]}}

    payload_sm = json.dumps(payload_sm_1)

    token_sm = "Bearer " +  token_dict["access_token"]
    headers_sm = {
        'Authorization': token_sm,
        'Content-Type': "application/json"
        }

    response = requests.request("POST", url_sm, data=payload_sm, headers=headers_sm)
    logging.info("mail send response status: " + str(response.status_code))
    logging.info(mail_subject + "  has been sent with attachment " + fileName_name +" , please check")
    


def fsendmail( to_mail_address,mail_subject,mail_content ):
    url = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/v2.0/token"
    payload = "client_id=0ba36ee4-3758-429b-94e9-23475626b55c&scope=mail.send%20mail.readwrite&refresh_token=OAQABAAAAAACQN9QBRU3jT6bcBQLZNUj7PZsd478_Q8wnqqQUsxY96lAnYqBUboga40sQC86KsvQdLyVUgVBHeIFv0kHBpD1eTu3jcrti20XBpG53_dOwPn4DJR5KO097U975BvrSyb3KF0rRrNBJr668cr6D5SDPQFJtBGBazLldzhMA9Lg7tdwxvoxwkc3eoN0nr_kPAwSMtyoo56x8leRHM1tth_Npm-pOe2yuvF8bJ3RL9lyrz5VN8iq8LOFrdjnytPu2W5IpWhMp2Ij-hkMsYCZ9O79Pz77lNspeCDHYL-4MJBxP7-U-w2AIkoRRasi-t6E1cRKKq6jLc2o2infnriYn4yNIKzMglrW57exfBK4SYSlPvH40_fWq5dqaNlm6V38_JAt8QnZBnhSNxrTAGkqrB03jrWp-S1xLZi_HQwWacvKeRugIpCFWnCuqSA-l_2dEBoPmFKvH02h8SpSRyoyVaQqAfMxbnEd4EqOmakYc9hbKSid9x1_bW4BiJEDnq_GZNZUbBeFFdBL4dvISckMrSwnCezc3sjpAmI_n8dsAUKrGlMm0tP0N99vlemw_0v4jAY_2iCkN8L2IvvOXHJyNOhQ8mmfy5qS9L4aRXlk1Mr2EYiRc04ZNwn-lALY_82IU0af4DFgOzEKCQ0c3pnleVzXmgz_k_pvanvJfh39h7F_YzTUt6AuN8ftmGH8kK0fzdSnLAlJEjed8u_RHpyg5lVJIqKOUE7Y1xVoz-UMoBCV4xL1kHvnkc2_p9C84ulw19cDN198i4RD8PF_5ylrEaGwfgI5ToRwjsETmZ0BFO-MkQvhcNY32oxaxa0CPcM1by_o-sBkyZCUt1wzSi6Cxa62wOuGeOjcZCPv3qGB-J3z2PILoSkdhJUENu8k0RLjFG_u6GndrvlDKPcLk7s50CBU3IAA&redirect_uri=http%3A%2F%2Flocalhost%3A8080&grant_type=refresh_token&client_secret=Y6f5ba3XhY%3DGpVc%5B.P8O%3F4xdyYJ1Arcq"
    headers = {	'Content-Type': "application/x-www-form-urlencoded" }
    response = requests.request("POST", url, data=payload, headers=headers)
    token_dict = json.loads(response.text)
    mailto = mailtofunc(to_mail_address)
    url_sm = "https://graph.microsoft.com/v1.0/users/b7ed64c8-2f97-4588-913a-7f60fabad6b9/sendmail"
    payload_sm_1 = {"message": {"subject": mail_subject,"body": {"contentType": "HTML","content": mail_content},"toRecipients": mailto}}

    payload_sm = json.dumps(payload_sm_1)

    token_sm = "Bearer " +  token_dict["access_token"]
    headers_sm = {
        'Authorization': token_sm,
        'Content-Type': "application/json"
        }

    response = requests.request("POST", url_sm, data=payload_sm, headers=headers_sm)
    logging.info("mail send response status: " + str(response.status_code))
    logging.info(mail_subject + "  has been sent, please check")