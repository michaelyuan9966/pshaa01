import datetime
import logging
import azure.functions as func
import pyodbc
import subprocess
import re
import json
import sys
import os
import datetime
import requests
from datetime import timedelta
# from exchangelib import DELEGATE, Account, Credentials, Configuration, Message, HTMLBody
from ..mail.smailfunc import fsendamail
from ..mail.smailfunc import fsendmail


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    # emailusername=os.environ["emailusername"]
    # emailpassword=os.environ["emailpassword"]
    # emailhost=os.environ["emailhost"]
    # credentials = Credentials(username=emailusername, password=emailpassword)
    # config = Configuration(server=emailhost, credentials=credentials)
    # account = Account(primary_smtp_address=emailusername, config=config,autodiscover=False, access_type=DELEGATE)
    # m = Message(account=account,subject=mail_subject,body = HTMLBody(mail_content),to_recipients=mailto)
    # m.send()
    # mailto_high = ["chunbin.tang@bhp.com","leo.wang@bhp.com","binghua.wu@bhp.com","tianhong.zhao@bhp.com","charles.liu@bhp.com","MCCSupportTeam@bhpbilliton.com","gabriella.wu@bhp.com","DL-TECH-SHA-MCCDevOps@bhpbilliton.com"]
    # mailto_normal = ["leo.wang@bhp.com","binghua.wu@bhp.com","tianhong.zhao@bhp.com","charles.liu@bhp.com","MCCSupportTeam@bhpbilliton.com"]
    mailto_high = "chunbin.tang@bhp.com;leo.wang@bhp.com;binghua.wu@bhp.com;tianhong.zhao@bhp.com;charles.liu@bhp.com;MCCSupportTeam@bhpbilliton.com;gabriella.wu@bhp.com;DL-TECH-SHA-MCCDevOps@bhpbilliton.com"
    mailto_normal = "leo.wang@bhp.com;binghua.wu@bhp.com;tianhong.zhao@bhp.com;charles.liu@bhp.com;MCCSupportTeam@bhpbilliton.com"
    # mailto_high = "michael.yuan@bhp.com"
    # mailto_normal = "michael.yuan@bhp.com"

    server_sql = os.environ["server_sql"]
    database_sql = os.environ["database_sql"]
    username_sql = os.environ["username_sql"]
    password_sql = os.environ["password_sql"]
    driver_sql = os.environ["driver_sql"]
    
    url_token = os.environ["url_token"]
    client_id = os.environ["client_id"]
    client_secret = os.environ["client_secret"]
    grant_type = os.environ["grant_type"]
    resource = os.environ["resource"]
    payload_token = {"client_id":client_id,"client_secret":client_secret,"grant_type":grant_type,"resource":resource}

    try:
        cnxn = pyodbc.connect('DRIVER='+driver_sql+';SERVER='+server_sql+';PORT=1433;DATABASE='+database_sql+';UID='+username_sql+';PWD='+ password_sql)
        cursor = cnxn.cursor()
    except Exception as error_sql_con:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("DataBase_Connect Error: " + database_sql + "################" + str(error_sql_con) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]: DataBase_Connect Error: " + database_sql
        mail_content = 'Dear'  + '<p>' + 'The DataBase of '+ database_sql + ' could not be connected, please check.<br>Detail error: ' + str(error_sql_con) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
        sys.exit(1)

    try:
        response_token = requests.request("GET", url_token, data=payload_token)
        respone_token_text = response_token.text
        respone_token_tojson = json.loads(respone_token_text)
        response_token_r = respone_token_tojson["access_token"]
    except Exception as get_token_error:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("DSApi_Get_Token Error: ################" + str(get_token_error) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]: DSApi_Get_Token"
        mail_content = 'Dear'  + '<p>' + 'DSApi_Get_Token erorr, please check.<br>Detail error: ' + str(get_token_error) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
        sys.exit(1)

    token_head_val = "Bearer "+ response_token_r
    headers = {'Authorization': token_head_val}

    try:
        #cursor.execute("select * from monitor_apiconfig where needcheck = 1")
        cursor.execute("select * from monitor_apiconfig where murl_name in ('Digital_API_Pro','BAT-PRD-API') and needcheck = 1")
        tables = cursor.fetchall()
        for row in tables:
            if row is not None:
                logging.info("##############################")
                logging.info(row)
                murl_name = row[1]
                murl = row[2]
                last_api_result_dict = {}
                http_code_lastcheck = 200
                sql_lastcheck = "SELECT top(1) http_code,api_status,api_result FROM monitor_mapi where murl_name = '" + murl_name +"' order by id desc"
                try:
                    cursor.execute(sql_lastcheck)
                    table_lastcheck = cursor.fetchall()
                    for row_lastcheck in table_lastcheck:
                        if row_lastcheck is not None:
                            http_code_lastcheck = int(row_lastcheck[0])
                            api_result_lastcheck = int(row_lastcheck[2])
                            api_result_lastcheck_list = json.loads(api_result_lastcheck)
                            for api_result_lastcheck_each_dict in api_result_lastcheck_list:
                                api_result_lastcheck_resource_tmp = api_result_lastcheck_each_dict["resource"]
                                api_result_lastcheck_status_tmp = api_result_lastcheck_each_dict["status"]
                                last_api_result_dict[api_result_lastcheck_resource_tmp] = api_result_lastcheck_status_tmp
                except Exception as last_sql_query_error:
                    logging.info(last_sql_query_error)
                    last_api_result_dict = {}

                try:
                    response = requests.request("GET", murl, headers=headers)
                    response_value = response.text
                    http_code = response.status_code
                    api_status = 1
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                
                except Exception as get_value_api_error:
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    logging.error("Request api result error:" + murl + "################" + str(get_value_api_error) + "################; Check Time: " + hours_8hours_later)

                    mail_subject = "[Critical]: Request api "+ murl + " result Error"
                    mail_content = 'Dear'  + '<p>' + 'Request api result error:' + murl + ', please check.<br>Detail error: ' + str(get_value_api_error) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
                    sys.exit(1)



                
                if http_code != 200 and http_code != http_code_lastcheck:
                    api_status = -1
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    mail_subject = '[Critical]' + murl_name + ' HTTP_CODE: ' + str(http_code)
                    mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' is ' + str(http_code) +'. Please check it.<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( mailto_high,mail_subject,mail_content )


                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,cdatetime) values('%s',%d,%d,'%s')"%(murl_name,http_code,api_status,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()

                    logging.info('Head log:' + str(headers))



                
                        
                if http_code == 200 and http_code != http_code_lastcheck:
                    api_status = 1
                    mail_subject = '[Critical]Resume: ' + murl_name + ' resume well. Now HTTP_CODE: ' + str(http_code)
                    mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' HTTP_CODE is ' + str(http_code) +'. Resume well.<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( mailto_high,mail_subject,mail_content )

                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,api_result,cdatetime) values('%s',%d,%d,'%s','%s')"%(murl_name,http_code,api_status,response_value,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()




                if http_code == 200 and http_code_lastcheck == 200:
                    response_value_list = json.loads(response_value)
                    if len(response_value_list) > 0:
                        for api_status_each_dict in response_value_list:
                            api_resource_tmp = api_status_each_dict["resource"]
                            api_status_tmp = api_status_each_dict["status"]
                            try:
                                api_status_last_tmp = last_api_result_dict["resource"]
                            except:
                                api_status_last_tmp = None

                            if api_status_last_tmp is None:
                                if api_status_tmp.upper() == "ABNORMAL" or api_status_tmp.upper() == "ERROR" and api_resource_tmp =="Azure SQL Server":
                                    mail_subject = '[Critical]'+ api_resource_tmp + ' Status: ' + api_status_tmp
                                    mail_content = 'Dear  all'  + '<p>' + 'The status of '+ api_resource_tmp + ' is ' + api_status_tmp +'. Please check it.<br>Link_URL: '+ murl + '<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                    fsendmail( mailto_high,mail_subject,mail_content )

                                elif api_status_tmp.upper() in ["PAUSED","BLOCKED","ERROR","ABNORMAL"] and api_resource_tmp !="Azure SQL Server":
                                    tmp_sql_insert = "insert into monitor_api_bpcheck(api_name,bpcheck_time,bpcheck_status) values('%s','%s',%d)"%(api_resource_tmp,hours_8hours_later,1)
                                    logging.info(tmp_sql_insert)
                                    cursor.execute(tmp_sql_insert)
                                    cursor.commit()
                            else:
                                if api_status_tmp.upper() == "ABNORMAL" or api_status_tmp.upper() == "ERROR" and api_resource_tmp =="Azure SQL Server":
                                    mail_subject = '[Critical]'+ api_resource_tmp + ' Status: ' + api_status_tmp
                                    mail_content = 'Dear  all'  + '<p>' + 'The status of '+ api_resource_tmp + ' is ' + api_status_tmp +'. Please check it.<br>Link_URL: '+ murl + '<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                    fsendmail( mailto_high,mail_subject,mail_content )
                                elif api_status_tmp.upper() not in ["PAUSED","BLOCKED","ERROR","ABNORMAL"] and api_resource_tmp == "Azure SQL Server":
                                    if api_status_tmp != api_status_last_tmp:
                                            mail_subject = '[Critical]Resumed '+api_resource_tmp + ' Status: ' + api_status_tmp + ' has been Resumed'
                                            mail_content = 'Dear  all'  + '<p>' + 'The status of '+ api_resource_tmp + ' is ' + api_status_tmp +' has been Resumed.<br>Link_URL: '+ murl + '<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                            fsendmail( mailto_high,mail_subject,mail_content )


                                elif api_status_tmp.upper() in ["PAUSED","BLOCKED","ERROR","ABNORMAL"] and api_resource_tmp != "Azure SQL Server":
                                    sql_lastcheck_api = "SELECT top(1) bpcheck_status FROM monitor_api_bpcheck where api_name = '" + api_resource_tmp +"' order by id desc"
                                    try:
                                        cursor.execute(sql_lastcheck_api)
                                        table_lastcheck_api = cursor.fetchall()
                                        for row_lastcheck_api in table_lastcheck_api:
                                            if row_lastcheck_api is not None:
                                                bpcheck_status_api = int(row[0])
                                                if bpcheck_status_api >= 6:
                                                    mail_subject = '[Middle]'+ api_resource_tmp + ' Status: ' + api_status_tmp + ' has been last 60Minutes'
                                                    mail_content = 'Dear  all'  + '<p>' + 'The status of '+ api_resource_tmp + ' is ' + api_status_tmp +' has been last 60Minutes. Please check it.<br>Link_URL: '+ input_url + '<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                                    fsendmail( mailto_normal,mail_subject,mail_content )
                                                    tmp_sql_insert_api = "update monitor_api_bpcheck set bpcheck_status = 1, bpcheck_time = '"+ hours_8hours_later +"' where api_name = '" + api_resource_tmp + "'"
                                                    cursor.execute(tmp_sql_insert_api)
                                                    cursor.commit()
                                                else:
                                                    bpcheck_status_api = int(bpcheck_status_api) + 1
                                                    tmp_sql_insert_api = "update monitor_api_bpcheck set bpcheck_status = "+str(bpcheck_status_api)+", bpcheck_time = '"+ hours_8hours_later +"' where api_name = '" + api_resource_tmp + "'"
                                                    cursor.execute(tmp_sql_insert_api)
                                                    cursor.commit()
                                    except Exception as echck:
                                        logging.error("Api_Health_Check_Last_Status_Error" + echck)


                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,api_result,cdatetime) values('%s',%d,%d,'%s','%s')"%(murl_name,http_code,api_status,response_value,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()


    except Exception as select_table_eror:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("Select table Error: monitor_apiconfig################" + str(select_table_eror) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]:Select table Error: monitor_apiconfig"
        mail_content = 'Dear'  + '<p>' + 'Select table Error: monitor_apiconfig################, please check.<br>Detail error: ' + str(select_table_eror) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )

        sys.exit(1)

    cnxn.close()