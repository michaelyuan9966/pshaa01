import datetime
import logging
import azure.functions as func
import pyodbc
import subprocess
import re
import json
import sys
import os
import datetime
import requests
from datetime import timedelta
from ..mail.smailfunc import fsendamail
from ..mail.smailfunc import fsendmail


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    #mailto_high = "chunbin.tang@bhp.com;leo.wang@bhp.com;binghua.wu@bhp.com;tianhong.zhao@bhp.com;charles.liu@bhp.com;MCCSupportTeam@bhpbilliton.com;gabriella.wu@bhp.com;DL-TECH-SHA-MCCDevOps@bhpbilliton.com"
    #mailto_normal = "leo.wang@bhp.com;binghua.wu@bhp.com;tianhong.zhao@bhp.com;charles.liu@bhp.com;MCCSupportTeam@bhpbilliton.com"
    mailto_high = "michael.yuan@bhp.com"
    mailto_normal = "michael.yuan@bhp.com"


    server_sql = os.environ["server_sql"]
    database_sql = os.environ["database_sql"]
    username_sql = os.environ["username_sql"]
    password_sql = os.environ["password_sql"]
    driver_sql = os.environ["driver_sql"]
    
    try:
        cnxn = pyodbc.connect('DRIVER='+driver_sql+';SERVER='+server_sql+';PORT=1433;DATABASE='+database_sql+';UID='+username_sql+';PWD='+ password_sql)
        cursor = cnxn.cursor()
    except Exception as error_sql_con:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("DataBase_Connect Error: " + database_sql + "################" + str(error_sql_con) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]: DataBase_Connect Error: " + database_sql
        mail_content = 'Dear'  + '<p>' + 'The DataBase of '+ database_sql + ' could not be connected, please check.<br>Detail error: ' + str(error_sql_con) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
        sys.exit(1)


    try:
        cursor.execute("select * from monitor_apiconfig  where murl_name in ('DS-Web-Pro','OSM-Fnc-Pro') and needcheck = 1")
        tables = cursor.fetchall()
        for row in tables:
            if row is not None:
                logging.info("##############################")
                logging.info(row)
                murl_name = row[1]
                murl = row[2]
                http_code_lastcheck = 200
                sql_lastcheck = "SELECT top(1) http_code,api_status,api_result FROM monitor_mapi where murl_name = " + murl_name +" order by id desc"
                try:
                    cursor.execute(sql_lastcheck)
                    table_lastcheck = cursor.fetchall()
                    if len(table_lastcheck) > 0:
                        for row_lastcheck in table_lastcheck:
                            if row_lastcheck is not None:
                                http_code_lastcheck = int(row_lastcheck[0])

                except Exception as last_sql_query_error:
                    logging.info(last_sql_query_error)

                try:
                    response = requests.request("GET", murl)
                    http_code = response.status_code
                    api_status = 1
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                
                except Exception as get_value_api_error:
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    logging.error("Request result error:" + murl + "################" + str(get_value_api_error) + "################; Check Time: " + hours_8hours_later)

                    mail_subject = "[Critical]: Request "+ murl + " result Error"
                    mail_content = 'Dear'  + '<p>' + 'Request result error:' + murl + ', please check.<br>Detail error: ' + str(get_value_api_error) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( mailto_high,mail_subject,mail_content )
                    sys.exit(1)


                if http_code != 200 and http_code != http_code_lastcheck:
                    api_status = -1
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    mail_subject = '[Critical]' + murl_name + ' HTTP_CODE: ' + str(http_code)
                    mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' is ' + str(http_code) +'. Please check it.<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( mailto_high,mail_subject,mail_content )


                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,cdatetime) values('%s',%d,%d,'%s')"%(murl_name,http_code,api_status,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()
                      
                if http_code == 200 and http_code != http_code_lastcheck:
                    api_status = 1
                    mail_subject = '[Critical]Resume: ' + murl_name + ' resume well. Now HTTP_CODE: ' + str(http_code)
                    mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' HTTP_CODE is ' + str(http_code) +'. Resume well.<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( mailto_high,mail_subject,mail_content )

                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,cdatetime) values('%s',%d,%d,'%s')"%(murl_name,http_code,api_status,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()



                if http_code == 200 and http_code == http_code_lastcheck:
                    api_status = 1
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,cdatetime) values('%s',%d,%d,'%s')"%(murl_name,http_code,api_status,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()




    except Exception as select_table_eror:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("Select table Error: monitor_apiconfig################" + str(select_table_eror) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]:Select table Error: monitor_apiconfig"
        mail_content = 'Dear'  + '<p>' + 'Select table Error: monitor_apiconfig################, please check.<br>Detail error: ' + str(select_table_eror) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )

        sys.exit(1)

    cnxn.close()