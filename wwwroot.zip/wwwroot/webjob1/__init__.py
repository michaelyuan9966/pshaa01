import datetime
import logging
import sys
import pyodbc
import json
import datetime
import requests
from datetime import timedelta

import azure.functions as func

from ..mail.smailfunc import fsendamail
from ..mail.smailfunc import fsendmail
from ..mail.smailfunc import fsendnamail
from ..funcSelf.funcSelf1 import webJobFunc

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    webJobFunc('197ea515-467a-49c1-a634-3b6a106ddf0a','productsuite-prd-aue-rg','pdfservice-prd-aue-web','bs-monthly-report')

        
