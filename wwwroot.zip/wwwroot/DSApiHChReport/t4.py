import datetime
import logging

import pyodbc
import os
import sys
import xlsxwriter
import subprocess
import re
import json
from datetime import timedelta
from exchangelib import DELEGATE, Account, Credentials, Configuration, Message, HTMLBody, FileAttachment

import azure.functions as func
import os.path
from io import BytesIO
import requests
import base64

from json import JSONEncoder

def dumper(obj):
    try:
        return obj.toJSON()
    except:
        return obj.__dict__


class FileItem:
    def __init__(self, fname):
        self.fname = fname

    def __repr__(self):
        return json.dumps(self.__dict__)




mailto_high = ["michael.yuan@bhp.com"]
mailto_normal = ["michael.yuan@bhp.com"]

# server_sql = os.environ["server_sql"]
# database_sql = os.environ["database_sql"]
# username_sql = os.environ["username_sql"]
# password_sql = os.environ["password_sql"]
# driver_sql = os.environ["driver_sql"]
# server_sql = "healthcheck-dev-sgp-sql.database.windows.net"
# database_sql = "healthcheck-dev-sgp-db"
# username_sql = "bhpadmin"
# password_sql = "Devops2019"
# driver_sql = "{ODBC Driver 17 for SQL Server}"


server_sql = "localhost"
database_sql = "healthcheck-dev-sgp-db"
username_sql = "sa"
password_sql = "Devops2019"
driver_sql = "{ODBC Driver 17 for SQL Server}"

curdate = datetime.date.today().strftime("%Y-%m-%d")

hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")



try:
    cnxn = pyodbc.connect('DRIVER='+driver_sql+';SERVER='+server_sql+';PORT=1433;DATABASE='+database_sql+';UID='+username_sql+';PWD='+ password_sql)
    cursor = cnxn.cursor()
except Exception as error_sql_con:
    
    logging.error("DataBase_Connect Error: " + database_sql + "################" + str(error_sql_con) + "################; Check Time: " + hours_8hours_later)
    sys.exit(1)

# emailusername=os.environ["emailusername"]
# emailpassword=os.environ["emailpassword"]
# emailhost=os.environ["emailhost"]
# emailusername='BHP_ProductSuite_MailBox_QA@bhp.com'
# emailpassword='yJs&4&kB'
# emailhost='outlook.office365.com'

# credentials = Credentials(username=emailusername, password=emailpassword)
# config = Configuration(server=emailhost, credentials=credentials)
# account = Account(primary_smtp_address=emailusername, config=config,autodiscover=False, access_type=DELEGATE)


curdate = datetime.date.today().strftime("%Y-%m-%d")
date_7days_ago = (datetime.datetime.now() + timedelta(days=-7)).strftime("%Y-%m-%d")

sql_truncate = "truncate table analysisapi"
cursor.execute(sql_truncate)
cnxn.commit()


query_murl = "select murl_name,murl from monitor_apiconfig"
cursor.execute(query_murl)
results_murl = cursor.fetchall()
for row_murl in results_murl:
    murlname = row_murl[0]
    murl = row_murl[1]


    sql_select = "select cdatetime,api_result from monitor_mapi where murl_name = " + "'" + murlname + "'" + " and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "'"
    # logging.info(sql_select)

    # resource_Status_val_int = 0
    stu_val = 'a'
    cursor.execute(sql_select)
    results_api = cursor.fetchall()
    for row_api in results_api:
        row_dtime = row_api[0]
        if row_api[1] is not None:
            row_api_list = json.loads(row_api[1])
            for resource in row_api_list:
                resource_name = resource['resource']
                resource_Status_val = resource['status']
                if resource_Status_val == 'OK':
                    OK_val = 1
                    stu_val = 'a'
                elif resource_Status_val.upper() == 'BLOCKED':
                    BLOCKED_val = 1
                    stu_val = 'b'
                elif resource_Status_val.upper() == 'PAUSED':
                    PAUSED_val = 1
                    stu_val = 'c'

                elif resource_Status_val.upper() == 'ERROR':
                    ERROR_val = 1
                    stu_val = 'd'
                elif resource_Status_val.upper() == 'ABNORMAL':
                    ABNORMAL = 1
                    stu_val = 'e'

                sql_insert_1 = "insert into analysisapi(murlname,resouce,cdatetime,status) values('" +str(murlname) +"','"+str(resource_name) +"','"+str(row_dtime)+"','" +str(stu_val)+"')"

                cursor.execute(sql_insert_1)
                cnxn.commit()


    murlname_ = murlname.replace(' ','_')
    fileName_name = murlname_ + '.xlsx'
    # if os.path.exists(fileName):
    #     os.remove(fileName)
    # else:
    #     logging.info("The file does not exist")

    fileName = BytesIO()
    workbook = xlsxwriter.Workbook(fileName)
    worksheet = workbook.add_worksheet('Data_Statistics')
    # logging.info(os.listdir())


    bold = workbook.add_format({'bold': 1})
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})
    font_orange = workbook.add_format({'font_color': '#ffa64d'})
    font_red = workbook.add_format({'font_color': '#FF6347'})

    cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})


    start_date = ""
    end_date = ""
    sql_q_date_start = "select top(1) left(cdatetime,10) as datestart from analysisapi order by id asc"
    cursor.execute(sql_q_date_start)
    results_start_date = cursor.fetchall()
    for row_start_date in results_start_date:
        start_date = row_start_date[0]


    sql_q_date_end = "select top(1) left(cdatetime,10) as dateend from analysisapi order by id desc"
    cursor.execute(sql_q_date_end)
    results_end_date = cursor.fetchall()
    for row_end_date in results_end_date:
        end_date = row_end_date[0]

    # logging.info("#############################################")
    # logging.info(start_date)
    # logging.info(end_date)
    # logging.info("#############################################")
    start_date_time = datetime.datetime.strptime(start_date,'%Y-%m-%d')
    end_date_time = datetime.datetime.strptime(end_date,'%Y-%m-%d')

    worksheet.set_column(0, 0, 36)
    worksheet.set_row(0, 20)

    row_nums_start = 0
    # logging.info(end_date_time)
    if start_date_time != end_date_time:
        worksheet.set_column(0, 0, 70)
        worksheet.write('A1', 'Services', cell_format_f)
        m = 0
        n = 0
        sheet_col = 0
        while m == 0:
            date_cur_tmp = start_date_time + timedelta(days=n)
            if date_cur_tmp == end_date_time:
                m = 1
            end_char_num = 66 + n
            sheet_index_f1 = chr(end_char_num) + str('1')
            sheet_val_f1 = date_cur_tmp.strftime('%Y-%m-%d')
            if date_cur_tmp <= end_date_time:
                worksheet.set_column(n+1, n+1, 19)
                worksheet.write(sheet_index_f1, sheet_val_f1, cell_format_f)

                sql_cell_contents = "select a.* from (select resouce,left(cdatetime,10) as mdate,COUNT(case when status='a' then 1 else null end) as 'OK',COUNT(case when status='b' then 1 else null end) as 'BLOCKED',COUNT(case when status='c' then 1 else null end) as 'PAUSED',COUNT(case when status='d' then 1 else null end) as 'ERROR',COUNT(case when status='e' then 1 else null end) as 'Abnormal' FROM analysisapi where cdatetime like '" + sheet_val_f1 + "%' group by left(cdatetime,10),resouce) a right join  (select distinct(resouce) as res from analysisapi) b  on b.res = a.resouce"

                # logging.info(sql_cell_contents)
                cursor.execute(sql_cell_contents)
                results_get_cont = cursor.fetchall()
                sheet_row = 1
                if len(results_get_cont) > 0:
                    for row in results_get_cont:
                        resouce = row[0]
                        if resouce is not None:
                            # logging.info("Resouce_logging########"+str(resouce))
                            resouce_OK = resouce + '_OK'
                            resouce_BLOCKED = resouce + '_BLOCKED'
                            resouce_PAUSED = resouce + '_PAUSED'
                            resouce_ERROR = resouce + '_ERROR'
                            resouce_Abnormal = resouce + '_Abnormal'
                            mdate = row[1]
                            OK = row[2]
                            BLOCKED = row[3]
                            PAUSED = row[4]
                            ERROR = row[5]
                            Abnormal = row[6]

                            sheet_index_sum_start = chr(end_char_num) + str(sheet_row+1)
                            sheet_index_sum_end = chr(end_char_num) + str(sheet_row+5)
                            if n == 0:
                                worksheet.write_string(sheet_row, sheet_col, resouce_OK)
                                worksheet.write_string(sheet_row+1, sheet_col, resouce_BLOCKED, font_orange)
                                worksheet.write_string(sheet_row+2, sheet_col, resouce_PAUSED, font_orange)
                                worksheet.write_string(sheet_row+3, sheet_col, resouce_ERROR, font_red)
                                worksheet.write_string(sheet_row+4, sheet_col, resouce_Abnormal, font_red)
                                worksheet.write_string(sheet_row+5, sheet_col, 'Sum')
                                worksheet.write_number(sheet_row, sheet_col+1, OK)
                                worksheet.write_number(sheet_row+1, sheet_col+1, BLOCKED, font_orange)
                                worksheet.write_number(sheet_row+2, sheet_col+1, PAUSED, font_orange)
                                worksheet.write_number(sheet_row+3, sheet_col+1, ERROR, font_red)
                                worksheet.write_number(sheet_row+4, sheet_col+1, Abnormal, font_red)

                            else:
                                worksheet.write_number(sheet_row, sheet_col+1, OK)
                                worksheet.write_number(sheet_row+1, sheet_col+1, BLOCKED, font_orange)
                                worksheet.write_number(sheet_row+2, sheet_col+1, PAUSED, font_orange)
                                worksheet.write_number(sheet_row+3, sheet_col+1, ERROR, font_red)
                                worksheet.write_number(sheet_row+4, sheet_col+1, Abnormal, font_red)

                            worksheet.write(sheet_row+5, sheet_col+1, '=SUM('+sheet_index_sum_start+':'+sheet_index_sum_end+')')

                            sheet_row += 7
                            row_nums_start = sheet_row


                # logging.info(row_nums_start)
                ##Exception####
                row_nums_start += 1
                exception_sql = "select count(*) as n200nums from monitor_mapi where murl_name= " + "'" + murlname + "'" + "  and http_code != 200 and left(cdatetime,10) = '" + sheet_val_f1 + "'"
                print(exception_sql)
                cursor.execute(exception_sql)
                exception_all = cursor.fetchall()
                for row_exceptions in exception_all:
                    exception_num = row_exceptions[0]
                    if sheet_col < 1:
                        worksheet.write_string(row_nums_start, sheet_col, 'Exception Error',font_red)
                        worksheet.write_number(row_nums_start, sheet_col+1, exception_num,font_red)
                    else:
                        worksheet.write_number(row_nums_start, sheet_col+1, exception_num,font_red)

                ##Exception####
                sheet_col += 1
                n += 1



    # logging.info(row_nums_start)
    row_nums_start += 3
    mulr_index = 'A' + str(row_nums_start)
    merge_uname_index1 = 'B' + str(row_nums_start)
    merge_uname_index2 = 'C' + str(row_nums_start)
    merge_time_index1 = 'D' + str(row_nums_start)
    merge_time_index2 = 'E' + str(row_nums_start)
    http_code_index = 'F' + str(row_nums_start)
    worksheet.write(mulr_index, 'URL', cell_format_f)
    worksheet.merge_range(merge_uname_index1 + ':' + merge_uname_index2, 'URL_Name',cell_format_f)
    worksheet.merge_range(merge_time_index1 + ':' + merge_time_index2, 'Date_Time',cell_format_f)
    worksheet.write(http_code_index, 'Http_Code', cell_format_f)

    merge_format_time = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})

    merge_format_time_normal = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})
    merge_format_normal_1 = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter'})

    sql_check_http_code = "select murl_name,cdatetime, http_code from monitor_mapi where murl_name= " + "'" + murlname + "'" + "  and http_code != 200 and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "'"
    logging.info("sql_check_http_code: " + sql_check_http_code)

    cursor.execute(sql_check_http_code)
    results_http_code = cursor.fetchall()
    if row_nums_start < 1:
        row_nums_start = 1

    for row_http_code in results_http_code:
        row_nums_start += 1

        murl_name = row_http_code[0]
        cdatetime = row_http_code[1]
        http_code = row_http_code[2]

        murl_index = 'A' + str(row_nums_start)
        merge_uname_index1 = 'B' + str(row_nums_start)
        merge_uname_index2 = 'C' + str(row_nums_start)

        merge_time_index1 = 'D' + str(row_nums_start)
        merge_time_index2 = 'E' + str(row_nums_start)
        http_code_index = 'F' + str(row_nums_start)

        worksheet.write(murl_index, murl, font_red)
        worksheet.merge_range(merge_uname_index1 + ':' + merge_uname_index2, murlname, merge_format_normal_1)
        worksheet.merge_range(merge_time_index1 + ':' + merge_time_index2, cdatetime, merge_format_time)
        worksheet.write(http_code_index, http_code, font_red)


    ####ADD DEPLOY Time
    # if row_nums_start < 1:
    #     row_nums_start = 1
    # row_nums_start += 2
    # murl_index = 'A' + str(row_nums_start)
    # merge_uname_index1 = 'B' + str(row_nums_start)
    # merge_uname_index2 = 'C' + str(row_nums_start)
    # merge_time_index1 = 'D' + str(row_nums_start)
    # merge_time_index2 = 'E' + str(row_nums_start)
    # worksheet.write(murl_index, 'URL_Name', cell_format_f)
    # worksheet.merge_range(merge_uname_index1 + ':' + merge_uname_index2, 'Deploy_StartTime',cell_format_f)
    # worksheet.merge_range(merge_time_index1 + ':' + merge_time_index2, 'Deploy_EndTime',cell_format_f)

    # sql_deploy = "select dstdatetime, denddatetime from monitor_deploytime where murlname= " + "'" + murlname + "'" + "  and dstdatetime >= '" + date_7days_ago + "' and dstdatetime < '" + curdate + "'"
    # # logging.info(sql_deploy)
    # num_rows = cursor.execute(sql_deploy)
    # results_deploy = cursor.fetchall()
    # if len(results_deploy) > 0:
    #     for row_deploy in results_deploy:
    #         row_nums_start += 1
    #         dstdatetime = row_deploy[0]
    #         denddatetime = row_deploy[1]
    #         murl_index = 'A' + str(row_nums_start)
    #         merge_uname_index1 = 'B' + str(row_nums_start)
    #         merge_uname_index2 = 'C' + str(row_nums_start)
    #         merge_time_index1 = 'D' + str(row_nums_start)
    #         merge_time_index2 = 'E' + str(row_nums_start)

    #         worksheet.write(murl_index, murlname)
    #         worksheet.merge_range(merge_uname_index1 + ':' + merge_uname_index2, dstdatetime, merge_format_time_normal)
    #         worksheet.merge_range(merge_time_index1 + ':' + merge_time_index2, denddatetime, merge_format_time_normal)









        ###HIDE SHEET#####
    worksheet_data = workbook.add_worksheet('Data_for_Charts')
    worksheet_chart = workbook.add_worksheet('Charts')
    worksheet_data.hide()

    data_all_resouce = []
    resouce_all_ok_list = []
    resouce_all_BLOCKED_list = []
    resouce_all_PAUSED_list = []
    resouce_all_ERROR_list = []
    resouce_all_abnormal_list = []

    headings_all = ['Number','OK','BLOCKED','PAUSED','ERROR','Abnormal']
    sql_cell_contents_all = "select resouce,COUNT(case when status='a' then 1 else null end) as 'OK',COUNT(case when status='b' then 1 else null end) as 'BLOCKED',COUNT(case when status='c' then 1 else null end) as 'PAUSED',COUNT(case when status='d' then 1 else null end) as 'ERROR',COUNT(case when status='e' then 1 else null end) as 'Abnormal' FROM analysisapi group by resouce"
    cursor.execute(sql_cell_contents_all)
    results_get_all = cursor.fetchall()

    row_all_num = 1
    for row_all in results_get_all:
        row_all_num += 1
        # logging.info(row_all_num)
        resouce = row_all[0]
        OK = row_all[1]
        BLOCKED = row_all[2]
        PAUSED = row_all[3]
        ERROR = row_all[4]
        Abnormal = row_all[5]

        data_all_resouce.append(resouce)
        resouce_all_ok_list.append(OK)
        resouce_all_BLOCKED_list.append(BLOCKED)
        resouce_all_PAUSED_list.append(PAUSED)
        resouce_all_ERROR_list.append(ERROR)
        resouce_all_abnormal_list.append(Abnormal)




    data_all = [data_all_resouce,resouce_all_ok_list,resouce_all_BLOCKED_list,resouce_all_PAUSED_list,resouce_all_ERROR_list,resouce_all_abnormal_list]

    worksheet_data.write_row('A1', headings_all, bold)
    worksheet_data.write_column('A2', data_all[0])
    worksheet_data.write_column('B2', data_all[1])
    worksheet_data.write_column('C2', data_all[2])
    worksheet_data.write_column('D2', data_all[3])
    worksheet_data.write_column('E2', data_all[4])
    worksheet_data.write_column('F2', data_all[5])




    chart3 = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
    chart3.add_series({
        # 'name':       '=Data_for_Charts!$C$1',
        'name':       'OK',
        'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
        'values':     '=Data_for_Charts!$B$2:$B$'+str(row_all_num),
        'fill':   {'color': '#3CB371'},
    })


    chart3.add_series({
        # 'name':       '=Data_for_Charts!$B$1',
        'name':       'BLOCKED',
        'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
        'values':     '=Data_for_Charts!$C$2:$C$'+str(row_all_num),
        'fill':   {'color': '#ff9933'},
    })
    chart3.add_series({
        # 'name':       '=Data_for_Charts!$B$1',
        'name':       'PAUSED',
        'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
        'values':     '=Data_for_Charts!$D$2:$D$'+str(row_all_num),
        'fill':   {'color': '#ffbf00'},
    })
    chart3.add_series({
        # 'name':       '=Data_for_Charts!$B$1',
        'name':       'ERROR',
        'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
        'values':     '=Data_for_Charts!$E$2:$E$'+str(row_all_num),
        'fill':   {'color': '#7e0023'},
    })
    chart3.add_series({
        # 'name':       '=Data_for_Charts!$B$1',
        'name':       'Abnormal',
        'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
        'values':     '=Data_for_Charts!$F$2:$F$'+str(row_all_num),
        'fill':   {'color': '#FF6347'},
    })
    chart3.set_x_axis({
        'name': 'All Resauces Statistics Chart',
        'name_font': {'size': 12, 'bold': True},
        'num_font':  {'italic': True, 'size': 7 },
    })

    # chart3.set_style(13)
    chart3.set_size({'width': 1090, 'height': 360})
    worksheet_chart.insert_chart('A1', chart3, {'x_offset': 0, 'y_offset': 10})

    start_y_offet = 160

    row_all_num += 2
    for resouce_single_val in data_all_resouce:
        row_start_num = row_all_num
        # logging.info(row_start_num)
        data_single_resauce = []
        data_single_mdate = []
        resouce_single_ok_list = []
        resouce_single_BLOCKED_list = []
        resouce_single_PAUSED_list = []
        resouce_single_ERROR_list = []
        resouce_single_abnormal_list = []

        sql_resouce_single = "select resouce,left(cdatetime,10) as mdate,COUNT(case when status='a' then 1 else null end) as 'OK',COUNT(case when status='b' then 1 else null end) as 'BLOCKED',COUNT(case when status='c' then 1 else null end) as 'PAUSED',COUNT(case when status='d' then 1 else null end) as 'ERROR',COUNT(case when status='e' then 1 else null end) as 'Abnormal' FROM analysisapi where resouce = '" + resouce_single_val + "' group by left(cdatetime,10),resouce order by left(cdatetime,10) asc"
        # logging.info("447 "+ sql_resouce_single)
        cursor.execute(sql_resouce_single)
        results_get_single = cursor.fetchall()
        if len(results_get_single) > 0:
            for row_single in results_get_single:
                mdate_val = row_single[1]
                OK_val = row_single[2]
                BLOCKED_val = row_single[3]
                PAUSED_val = row_single[4]
                ERROR_val = row_single[5]
                Abnormal_val = row_single[6]

                data_single_resauce.append(resouce_single_val)
                data_single_mdate.append(mdate_val)
                resouce_single_ok_list.append(OK_val)
                resouce_single_BLOCKED_list.append(BLOCKED_val)
                resouce_single_PAUSED_list.append(PAUSED_val)
                resouce_single_ERROR_list.append(ERROR_val)
                resouce_single_abnormal_list.append(Abnormal_val)
                row_all_num += 1

        start_real_num = row_start_num + 1
        data_single_all_tmp = [data_single_resauce,data_single_mdate,resouce_single_ok_list,resouce_single_BLOCKED_list,resouce_single_PAUSED_list,resouce_single_ERROR_list,resouce_single_abnormal_list]
        sheet_column_index_resauce = 'A' + str(start_real_num)
        sheet_column_index_date = 'B' + str(start_real_num)
        sheet_column_index_ok = 'C' + str(start_real_num)
        sheet_column_index_BLOCKED = 'D' + str(start_real_num)
        sheet_column_index_PAUSED = 'E' + str(start_real_num)
        sheet_column_index_ERROR = 'F' + str(start_real_num)
        sheet_column_index_abnormal = 'G' + str(start_real_num)

        worksheet_data.write_column(sheet_column_index_resauce, data_single_all_tmp[0])
        worksheet_data.write_column(sheet_column_index_date, data_single_all_tmp[1])
        worksheet_data.write_column(sheet_column_index_ok, data_single_all_tmp[2])
        worksheet_data.write_column(sheet_column_index_BLOCKED, data_single_all_tmp[3])
        worksheet_data.write_column(sheet_column_index_PAUSED, data_single_all_tmp[4])
        worksheet_data.write_column(sheet_column_index_ERROR, data_single_all_tmp[5])
        worksheet_data.write_column(sheet_column_index_abnormal, data_single_all_tmp[6])
        chart_tmp = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
        chart_tmp.add_series({
            'name':       '=OK',
            'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
            'values':     '=Data_for_Charts!$C$'+str(start_real_num)+':$C$'+str(row_all_num),
            'fill':   {'color': '#3CB371'},
        })
        chart_tmp.add_series({
            'name':       '=BLOCKED',
            'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
            'values':     '=Data_for_Charts!$D$'+str(start_real_num)+':$D$'+str(row_all_num),
            'fill':   {'color': '#ff9933'},
        })
        chart_tmp.add_series({
            'name':       '=PAUSED',
            'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
            'values':     '=Data_for_Charts!$E$'+str(start_real_num)+':$E$'+str(row_all_num),
            'fill':   {'color': '#ffbf00'},
        })
        chart_tmp.add_series({
            'name':       '=ERROR',
            'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
            'values':     '=Data_for_Charts!$F$'+str(start_real_num)+':$F$'+str(row_all_num),
            'fill':   {'color': '#7e0023'},
        })
        chart_tmp.add_series({
            'name':       '=Abnormal',
            'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
            'values':     '=Data_for_Charts!$G$'+str(start_real_num)+':$G$'+str(row_all_num),
            'fill':   {'color': '#FF6347'},
        })


        chart_tmp.set_x_axis({
            'name': resouce_single_val + ' Chart',
            'name_font': {'size': 12, 'bold': True},
            'num_font':  {'italic': True, 'size': 7 },
        })

        # chart_tmp.set_style(13)
        chart_tmp.set_size({'width': 1090, 'height': 200})
        AX_chart = 'A' + str(start_real_num)
        worksheet_chart.insert_chart(AX_chart, chart_tmp, {'x_offset': 0, 'y_offset': start_y_offet})
        start_y_offet += 210


    dict_all = {}
    sql_select_fir = "select distinct(resouce) as dresouce from analysisapi"
    numrows = cursor.execute(sql_select_fir)
    result_f = cursor.fetchall()
    if len(result_f) > 0:
        for row_f in result_f:
            rname = row_f[0]
            rname_list = []
            if rname is not None:
                cursor.close
                sql_query_single="select cdatetime,resouce,status from analysisapi where resouce='"+ rname +"'"
                numrows_1 = cursor.execute(sql_query_single)
                result_sin = cursor.fetchall()

                if len(result_sin) > 0:
                    for row_sin in result_sin:
                        list_tmp = []
                        cdatetime_sin = row_sin[0]
                        resouce_sin = row_sin[0]
                        status_sin = row_sin[2]
                        if cdatetime_sin is not None and status_sin is not None:
                            list_tmp.append(cdatetime_sin)
                            list_tmp.append(status_sin)
                        rname_list.append(list_tmp)

            dict_all[rname] = rname_list


    disk_all_check = {}
    for k_rname, v_list_all in dict_all.items():
        list_problem_time = []
        if len(v_list_all) == 0:
            list_problem_time = [['No Exception Time']]
        elif len(v_list_all) == 1:
            if v_list_all[0][1] != 'a':
                list_problem_time.append(v_list_all[0][0])
                disk_all_check[k_rname]=[1,list_problem_time]
            elif v_list_all[0][1] == 'a':
                list_problem_time = [['No Exception Time']]
        elif len(v_list_all) == 2:
            if v_list_all[0][1] != v_list_all[1][1]:
                if v_list_all[0][1] == 'a':
                    list_problem_time.append(v_list_all[1][0])
                    disk_all_check[k_rname]= list_problem_time
                elif v_list_all[1][1] == 'a':
                    list_problem_time.append(v_list_all[0][0])
                    list_problem_time.append(v_list_all[1][0])

                else:
                    list_problem_time = [['No Exception Time']]
                    disk_all_check[k_rname]= list_problem_time
            elif v_list_all[0][1] != 'a' and v_list_all[1][1] != 'a':

                list_problem_time.append(v_list_all[0][0])

            else:
                list_problem_time = [['No Exception Time']]
        elif len(v_list_all) > 2:
            vlist_len = len(v_list_all)
            x=0
            while x < vlist_len:
                tmp_time_list=[]
                problem_time_tmp_start = None
                problem_time_tmp_end = None
                tmp_num_check01 = 0
                if v_list_all[x][1]!='a':
                    problem_time_tmp_start = v_list_all[x][0]
                    tmp_time_list.append(problem_time_tmp_start)
                    tmp_num_check01 = 0
                    while x + tmp_num_check01 + 1 < vlist_len:
                        if v_list_all[x+tmp_num_check01+1][1]=='a' and v_list_all[x+tmp_num_check01][1]!='a':
                            problem_time_tmp_end = v_list_all[x+tmp_num_check01][0]
                            if problem_time_tmp_end != problem_time_tmp_start:
                                tmp_time_list.append(problem_time_tmp_end)
                            break
                        tmp_num_check01+=1
                if len(tmp_time_list) > 0:
                    list_problem_time.append(tmp_time_list)
                tmp_time_list=[]
                x=x+1+tmp_num_check01
            if len(list_problem_time) < 1:
                list_problem_time=[['No Exception Time']]
            # logging.info(list_problem_time)
        disk_all_check[k_rname]=list_problem_time




    cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})
    ###############################################



    worksheet_accident  = workbook.add_worksheet('Accident_Statistics')

    worksheet_accident.set_column(0, 0, 70)
    worksheet_accident.write('A1', 'Services', cell_format_f)
    worksheet_accident.set_column(1, 1, 19)
    worksheet_accident.set_column(2, 2, 40)
    worksheet_accident.write('B1', 'Count', cell_format_f)
    worksheet_accident.write('C1', 'Time', cell_format_f)

    cell_format_center = workbook.add_format()
    cell_format_center.set_align('center')
    cell_format_center.set_align('vcenter')

    cell_format_center_v = workbook.add_format()
    cell_format_center_v.set_align('vcenter')
    init_k=2
    v_len_check=2

    for k, v in disk_all_check.items():
        tmp_v_list_len = len(v)
        # logging.info("###v####")
        # logging.info(tmp_v_list_len)
        # logging.info(k)
        # logging.info(v)
        # logging.info(v[0][0])
        if isinstance(v[0], list) is False and tmp_v_list_len == 1:
            worksheet_accident.write('A'+str(v_len_check), k)
            worksheet_accident.write('B'+str(v_len_check),1, cell_format_center)
            worksheet_accident.write('C'+str(v_len_check),str(v[0]), cell_format_center)
            v_len_check += 1
        elif v[0][0]=='No Exception Time' and tmp_v_list_len == 1:
            worksheet_accident.write('A'+str(v_len_check), k)
            worksheet_accident.write('B'+str(v_len_check),0, cell_format_center)
            worksheet_accident.write('C'+str(v_len_check),'No Exception Time',cell_format_center)
            v_len_check += 1
        elif v[0][0]!='No Exception Time' and tmp_v_list_len == 1:
            worksheet_accident.write('A'+str(v_len_check), k)
            worksheet_accident.write('B'+str(v_len_check),1, cell_format_center)
            worksheet_accident.write('C'+str(v_len_check),v[0][0], cell_format_center)
            v_len_check += 1
        if tmp_v_list_len > 1:
            v_loop_num = 0
            tmp_row_merge = v_len_check

            while v_loop_num < tmp_v_list_len:
                tmp_list_v = v[v_loop_num]
                tmp_list_v_len = len(tmp_list_v)
                # logging.info(tmp_list_v_len)
                if tmp_list_v_len == 1:
                    worksheet_accident.write('C'+str(v_len_check), str(v[v_loop_num][0]),cell_format_center)
                if tmp_list_v_len == 2:
                    worksheet_accident.write('C'+str(v_len_check), str(v[v_loop_num][0])+'~'+str(v[v_loop_num][1]),cell_format_center)

                v_loop_num += 1
                v_len_check += 1

            tmp_row_nums_merge = tmp_v_list_len
            merge_count_index1 = 'B' + str(tmp_row_merge)
            merge_count_index2 = 'B' + str(tmp_row_merge + tmp_row_nums_merge - 1)
            merge_resouce_index1 = 'A' + str(tmp_row_merge)
            merge_resouce_index2 = 'A' + str(tmp_row_merge + tmp_row_nums_merge - 1)

            worksheet_accident.merge_range(merge_count_index1 + ':' + merge_count_index2, tmp_v_list_len, cell_format_center)
            worksheet_accident.merge_range(merge_resouce_index1 + ':' + merge_resouce_index2, k, cell_format_center_v)

    # cursor.close()
    # cnxn.close()
    # workbook.close()






    # workbook.close()
    try:
        workbook.close()
    except Exception as workbookcloseError:
        logging.error(workbookcloseError)

    # fvalue = fileName.getvalue()
    # fvalue_de = fvalue.decode("utf-8","ignore")
    # fileName_data_1 = base64.encodestring(fvalue_de)
    # fileName_data = fileName_data_1.decode("utf-8","ignore")

    # fvalue = fileName.getvalue()
    # fbbvalue = base64.b64encode(fvalue)
    # fileName_data = fbbvalue.decode("utf-8","ignore")



    # mailto = ['michael.yuan@bhp.com','yuanshuai9916@gmail.com']
    # mailto = 'leo.wang@bhp.com;binghua.wu@bhp.com;charles.liu@bhp.com;tianhong.zhao@bhp.com;chunbin.tang@bhp.com;gabriella.wu@bhp.com;MCCSupportTeam@bhpbilliton.com;DL-TECH-SHA-MCCDevOps@bhpbilliton.com'
    mail_subject = murlname + ' data Statistics'
    mail_content = "<b>Hi All</b><p> The attachment is "+murlname+" weekly  data Statistics, please review.<br><br> <font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br>Best Regards!</br>  <b>MCC Release and Support Team</b>"
    
    url_gett1 = "https://login.microsoftonline.com/common/oauth2/v2.0/token"

    payload_gett1 = """client_id=bec85ed3-4933-480e-be1b-2e253f51e778&scope=mail.send%20mail.readwrite&refresh_token=OAQABAAAAAACQN9QBRU3jT6bcBQLZNUj7PaIIbxiZmozag0_17pZWoqlRvGJnDSTnvl4uVL4wgHkUsnFGJFui0bgc3LB_31gRmDZ5zanQrLRaJOCncglSwqQ1J1Zc-k8rF0o7J5TLL4vtiBKnCRxDx2WWGN1BAxBf3aQCCYr7EOO9iPqI9s3_4YQBbd-yZAItpd6bYJU4Ilbl5Qsd6rzKdpaZNRoD0GC_sEbWdP9J4FwaGRlhsD3ceo_R23KovPaotjJnyPvlJx7_5f25OHUPOQoQ0MCU2ljrZ-lYsWLpNlwEU7toMU93CAsQcNlq7zDHTfYAvxgDi1-T0Vd7L-CgsRQ-GC_AHmfBSPqo0MqOwl0SWbAIcvJFMZ0ibLS1oz7GudKH5uBrQ4e7_AJ3c7hHPVe5GmU7h88j34cg1ADHMxWe_MwWG2ytwOpLIANr8ksXiQZNUnmdIaz1RtD7-6zitC_brI9o3YmzX4RRd1oRvcDzQBfUej1D-x9164Yayt_4vPgxan8DHTUFDLDSd5Cmh-i0TxKxNH08Y_KqGNu7hFailH7yP1HD9MqFy0m_bfyfbUVU0YG6TfWkWiTVfGih0icTCVIX6JaqYPgcXt50iPE0L28diTXyOIclWaCiAWhxSqgtNLbS0HLpn2jf7e_568Dn3ZQLsg65a8Y6-IKdZI72EAdeMBXKiOt70C43MT1QaX-3TZkBTxMxRRBembVw2dKOzRdXhDSDme-iuANIcBfpeaKS_10iGne-D94dB2k_QF9FT-3wdhlFnOuPrgL5wECurtem-RPA4HeYQsj9xqsxRZcB6KuqDhlFe_UzLftyoucmz1mjHGn279Se6b3oDNoeM9_HIfEVR8Kxe9Ssjcim0iP28fn7ZzW1mhklCFnNCxBMuQiypvIc8lxSgETOYtgu49_HkPfwIAA&redirect_uri=http%3A%2F%2Flocalhost%3A8080&grant_type=refresh_token&client_secret=KThOwCsY%40sM%2FwSt%5D3KIc8X.rlgWAzK34"""
    headers_gett1 = {	'Content-Type': "application/x-www-form-urlencoded" }

    response_gett1 = requests.request("POST", url_gett1, data=payload_gett1, headers=headers_gett1)
    token_dict = json.loads(response_gett1.text)


    fileName_data = base64.b64encode(fileName.getvalue()).decode()

    url_sm = "https://graph.microsoft.com/v1.0/users/b7ed64c8-2f97-4588-913a-7f60fabad6b9/sendmail"
    # fileName = "a1.xlsx"
    payload_sm_1 = {"message": {"subject": mail_subject,"body": {"contentType": "HTML","content": mail_content},"toRecipients": [{"emailAddress":{"address": "michael.yuan@bhp.com"}},{"emailAddress":{"address": "yuanshuai9916@gmail.com"}}], "attachments":[{"@odata.type":"#Microsoft.OutlookServices.FileAttachment","name":fileName_name,"contentBytes":fileName_data}]}}

 
    payload_sm = json.dumps(payload_sm_1)
   



    token_sm = "Bearer " +  token_dict["access_token"]
    headers_sm = {
        'Authorization': token_sm,
        'Content-Type': "application/json"
        }

    response = requests.request("POST", url_sm, data=payload_sm, headers=headers_sm)
    # response = requests.request("POST", url_sm, json={'json_payload': payload_sm_1}, headers=headers_sm)
    



    # cpath = os.getcwd()
    # # file_path = cpath + '/' + fileName
    # # pwdpath = os.system('pwd')
    # # logging.info(cpath)

    # # logging.info(os.listdir())
    # fileName_data = fileName.getvalue()
    # # logging.info(fileName_data)

    # excelfname = murlname_ + '.xlsx'

    # m = Message(
    #     account=account,
    #     subject=mail_subject,
    #     body = HTMLBody(mail_content),
    #     to_recipients=[mailto]
    # )

    
    # my_attach_file = FileAttachment(name=excelfname, content=fileName_data)
    # m.attach(my_attach_file)
    
    # m.send()

# cursor.close()
cnxn.close()