import datetime
import logging

import pyodbc
import os
import sys
import xlsxwriter
import subprocess
import re
import json
from datetime import timedelta

import azure.functions as func
import os.path
from io import BytesIO
import requests
import base64

from azure.mgmt.monitor import MonitorManagementClient
from azure.common.credentials import ServicePrincipalCredentials

# from cacheout import Cache



from ..mail.smailfunc import fsendamail
from ..mail.smailfunc import fsendmail
from ..mail.smailfunc import fsendnamail




def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)


    # cache = Cache(maxsize=256, ttl=0, timer=time.time, default=None)

    mailto_high = ["michael.yuan@bhp.com"]
    mailto_normal = ["michael.yuan@bhp.com"]

    server_sql = "healthcheck-dev-sgp-sql.database.windows.net"
    database_sql = "healthcheck-dev-sgp-db"
    username_sql = "bhpadmin"
    password_sql = "Devops2019"
    driver_sql = "{ODBC Driver 17 for SQL Server}"
    
    curdate = datetime.date.today().strftime("%Y-%m-%d")

    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")



    try:
        cnxn = pyodbc.connect('DRIVER='+driver_sql+';SERVER='+server_sql+';PORT=1433;DATABASE='+database_sql+';UID='+username_sql+';PWD='+ password_sql)
        cursor = cnxn.cursor()
    except Exception as error_sql_con:
        
        logging.error("DataBase_Connect Error: " + database_sql + "################" + str(error_sql_con) + "################; Check Time: " + hours_8hours_later)
        sys.exit(1)
    


    curdate = datetime.date.today().strftime("%Y-%m-%d")
    date_7days_ago = (datetime.datetime.now() + timedelta(days=-7)).strftime("%Y-%m-%d")

    sql_truncate = "truncate table analysisapi"
    cursor.execute(sql_truncate)
    cnxn.commit()
    attachments = []

    #query_murl = "select murl_name,murl from monitor_apiconfig"
    query_murl = "select top(1000) murl_name,murl from monitor_apiconfig where murl_name in ('Digital_API_Pro','BAT-PRD-API') order by murl_name desc"
    cursor.execute(query_murl)
    results_murl = cursor.fetchall()


    


    for row_murl in results_murl:
        murlname = row_murl[0]
        murl = row_murl[1]


        sql_select = "select cdatetime,api_result from monitor_mapi where murl_name = " + "'" + murlname + "'" + " and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "'"
        # logging.info(sql_select)

        # resource_Status_val_int = 0
        stu_val = 'a'
        cursor.execute(sql_select)
        results_api = cursor.fetchall()
        for row_api in results_api:
            row_dtime = row_api[0]
            if row_api[1] is not None:
                row_api_list = json.loads(row_api[1])
                for resource in row_api_list:
                    resource_name = resource['resource']
                    resource_Status_val = resource['status']
                    if resource_Status_val == 'OK':
                        OK_val = 1
                        stu_val = 'a'
                    elif resource_Status_val.upper() == 'BLOCKED':
                        BLOCKED_val = 1
                        stu_val = 'b'
                    elif resource_Status_val.upper() == 'PAUSED':
                        PAUSED_val = 1
                        stu_val = 'c'

                    elif resource_Status_val.upper() == 'ERROR':
                        ERROR_val = 1
                        stu_val = 'd'
                    elif resource_Status_val.upper() == 'ABNORMAL':
                        ABNORMAL = 1
                        stu_val = 'e'

                    sql_insert_1 = "insert into analysisapi(murlname,resouce,cdatetime,status) values('" +str(murlname) +"','"+str(resource_name) +"','"+str(row_dtime)+"','" +str(stu_val)+"')"

                    cursor.execute(sql_insert_1)
                    cnxn.commit()


        murlname_ = murlname.replace(' ','_')
        if murlname_ == 'Digital_API_Pro':
            murlname_ = 'DS_API_SQL'
        else:
            murlname_ = 'DS_API_Batch'

        fileName_name = murlname_ + '.xlsx'

        fileName = BytesIO()
        fileName.seek(0)
        fileName.truncate(0)

        # logging.info("#############filebyte##############" + (fileName.getvalue()).decode("utf-8"))
        workbook = xlsxwriter.Workbook(fileName)
        worksheet_data_statistics = workbook.add_worksheet('Data_Statistics')
        # logging.info(os.listdir())


        bold = workbook.add_format({'bold': 1})
        date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})
        font_orange = workbook.add_format({'font_color': '#ffa64d'})
        font_red = workbook.add_format({'font_color': '#FF6347'})
        font_green = workbook.add_format({'font_color': '#3CB371'})

        cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})


        start_date = ""
        end_date = ""
        sql_q_date_start = "select top(1) left(cdatetime,10) as datestart from analysisapi order by id asc"
        cursor.execute(sql_q_date_start)
        results_start_date = cursor.fetchall()
        for row_start_date in results_start_date:
            start_date = row_start_date[0]


        sql_q_date_end = "select top(1) left(cdatetime,10) as dateend from analysisapi order by id desc"
        cursor.execute(sql_q_date_end)
        results_end_date = cursor.fetchall()
        for row_end_date in results_end_date:
            end_date = row_end_date[0]
        start_date_time = datetime.datetime.strptime(start_date,'%Y-%m-%d')
        end_date_time = datetime.datetime.strptime(end_date,'%Y-%m-%d')

        worksheet_data_statistics.set_column(0, 0, 36)
        worksheet_data_statistics.set_row(0, 20)

        row_nums_start = 0
        # logging.info(end_date_time)
        if start_date_time != end_date_time:
            worksheet_data_statistics.set_column(0, 0, 70)
            worksheet_data_statistics.write('A1', 'Services', cell_format_f)
            m = 0
            n = 0
            sheet_col = 0
            while m == 0:
                date_cur_tmp = start_date_time + timedelta(days=n)
                if date_cur_tmp == end_date_time:
                    m = 1
                end_char_num = 66 + n
                sheet_index_f1 = chr(end_char_num) + str('1')
                sheet_val_f1 = date_cur_tmp.strftime('%Y-%m-%d')
                if date_cur_tmp <= end_date_time:
                    worksheet_data_statistics.set_column(n+1, n+1, 19)
                    worksheet_data_statistics.write(sheet_index_f1, sheet_val_f1, cell_format_f)

                    sql_cell_contents = "select b.resouce,'" + sheet_val_f1 + "' as mdate,ISNULL(a.OK,0) as OK,ISNULL(a.BLOCKED,0) as BLOCKED,ISNULL(a.PAUSED,0) as PAUSED,ISNULL(a.ERROR,0) as ERROR,ISNULL(a.Abnormal,0) as Abnormal from (select resouce,left(cdatetime,10) as mdate,COUNT(case when status='a' then 1 else null end) as 'OK',COUNT(case when status='b' then 1 else null end) as 'BLOCKED',COUNT(case when status='c' then 1 else null end) as 'PAUSED',COUNT(case when status='d' then 1 else null end) as 'ERROR',COUNT(case when status='e' then 1 else null end) as 'Abnormal' FROM analysisapi where cdatetime like '" + sheet_val_f1 + "%' and murlname='"+ murlname +"' group by left(cdatetime,10),resouce) a right join  (select distinct(resouce) as resouce from analysisapi where murlname='"+ murlname +"') b  on b.resouce = a.resouce order by b.resouce"


                    # logging.info(sql_cell_contents)


                    cursor.execute(sql_cell_contents)
                    results_get_cont = cursor.fetchall()
                    sheet_row = 1
                    if len(results_get_cont) > 0:
                        for row in results_get_cont:
                            resouce = row[0]
                            if resouce is not None:
                                # logging.info("Resouce_logging########"+str(resouce))
                                resouce_OK = resouce + '_OK'
                                resouce_BLOCKED = resouce + '_BLOCKED'
                                resouce_PAUSED = resouce + '_PAUSED'
                                resouce_ERROR = resouce + '_ERROR'
                                resouce_Abnormal = resouce + '_Abnormal'
                                mdate = row[1]
                                OK = row[2]
                                BLOCKED = row[3]
                                PAUSED = row[4]
                                ERROR = row[5]
                                Abnormal = row[6]

                                sheet_index_sum_start = chr(end_char_num) + str(sheet_row+1)
                                sheet_index_sum_end = chr(end_char_num) + str(sheet_row+5)
                                if n == 0:
                                    worksheet_data_statistics.write_string(sheet_row, sheet_col, resouce_OK, font_green)
                                    worksheet_data_statistics.write_string(sheet_row+1, sheet_col, resouce_BLOCKED, font_orange)
                                    worksheet_data_statistics.write_string(sheet_row+2, sheet_col, resouce_PAUSED, font_orange)
                                    worksheet_data_statistics.write_string(sheet_row+3, sheet_col, resouce_ERROR, font_red)
                                    worksheet_data_statistics.write_string(sheet_row+4, sheet_col, resouce_Abnormal, font_red)
                                    worksheet_data_statistics.write_string(sheet_row+5, sheet_col, 'Sum')
                                    worksheet_data_statistics.write_number(sheet_row, sheet_col+1, OK)
                                    worksheet_data_statistics.write_number(sheet_row+1, sheet_col+1, BLOCKED, font_orange)
                                    worksheet_data_statistics.write_number(sheet_row+2, sheet_col+1, PAUSED, font_orange)
                                    worksheet_data_statistics.write_number(sheet_row+3, sheet_col+1, ERROR, font_red)
                                    worksheet_data_statistics.write_number(sheet_row+4, sheet_col+1, Abnormal, font_red)

                                else:
                                    worksheet_data_statistics.write_number(sheet_row, sheet_col+1, OK)
                                    worksheet_data_statistics.write_number(sheet_row+1, sheet_col+1, BLOCKED, font_orange)
                                    worksheet_data_statistics.write_number(sheet_row+2, sheet_col+1, PAUSED, font_orange)
                                    worksheet_data_statistics.write_number(sheet_row+3, sheet_col+1, ERROR, font_red)
                                    worksheet_data_statistics.write_number(sheet_row+4, sheet_col+1, Abnormal, font_red)

                                worksheet_data_statistics.write(sheet_row+5, sheet_col+1, '=SUM('+sheet_index_sum_start+':'+sheet_index_sum_end+')')

                                sheet_row += 7
                                row_nums_start = sheet_row


                    # logging.info(row_nums_start)
                    ##Exception####
                    row_nums_start += 1
                    exception_sql = "select count(*) as n200nums from monitor_mapi where murl_name= " + "'" + murlname + "'" + "  and http_code != 200 and left(cdatetime,10) = '" + sheet_val_f1 + "'"
                    cursor.execute(exception_sql)
                    exception_all = cursor.fetchall()
                    for row_exceptions in exception_all:
                        exception_num = row_exceptions[0]
                        if sheet_col < 1:
                            worksheet_data_statistics.write_string(row_nums_start, sheet_col, 'Exception Error',font_red)
                            worksheet_data_statistics.write_number(row_nums_start, sheet_col+1, exception_num,font_red)
                        else:
                            worksheet_data_statistics.write_number(row_nums_start, sheet_col+1, exception_num,font_red)

                    ##Exception####
                    sheet_col += 1
                    n += 1



        # logging.info(row_nums_start)
        row_nums_start += 3
        mulr_index = 'A' + str(row_nums_start)
        merge_uname_index1 = 'B' + str(row_nums_start)
        merge_uname_index2 = 'C' + str(row_nums_start)
        merge_time_index1 = 'D' + str(row_nums_start)
        merge_time_index2 = 'E' + str(row_nums_start)
        http_code_index = 'F' + str(row_nums_start)
        worksheet_data_statistics.write(mulr_index, 'URL', cell_format_f)
        worksheet_data_statistics.merge_range(merge_uname_index1 + ':' + merge_uname_index2, 'URL_Name',cell_format_f)
        worksheet_data_statistics.merge_range(merge_time_index1 + ':' + merge_time_index2, 'Date_Time',cell_format_f)
        worksheet_data_statistics.write(http_code_index, 'Http_Code', cell_format_f)

        merge_format_time = workbook.add_format({
            'font_color': '#FF6347',
            'align': 'center',
            'valign': 'vcenter',
            'num_format': 'yyyy-mm-dd hh:mm:ss'})

        merge_format_time_normal = workbook.add_format({
            'align': 'center',
            'valign': 'vcenter',
            'num_format': 'yyyy-mm-dd hh:mm:ss'})
        merge_format_normal_1 = workbook.add_format({
            'font_color': '#FF6347',
            'align': 'center',
            'valign': 'vcenter'})

        sql_check_http_code = "select murl_name,cdatetime, http_code from monitor_mapi where murl_name= " + "'" + murlname + "'" + "  and http_code != 200 and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "'"
        logging.info("sql_check_http_code: " + sql_check_http_code)

        cursor.execute(sql_check_http_code)
        results_http_code = cursor.fetchall()
        if row_nums_start < 1:
            row_nums_start = 1

        for row_http_code in results_http_code:
            row_nums_start += 1

            murl_name = row_http_code[0]
            cdatetime = row_http_code[1]
            http_code = row_http_code[2]

            murl_index = 'A' + str(row_nums_start)
            merge_uname_index1 = 'B' + str(row_nums_start)
            merge_uname_index2 = 'C' + str(row_nums_start)

            merge_time_index1 = 'D' + str(row_nums_start)
            merge_time_index2 = 'E' + str(row_nums_start)
            http_code_index = 'F' + str(row_nums_start)

            worksheet_data_statistics.write(murl_index, murl, font_red)
            worksheet_data_statistics.merge_range(merge_uname_index1 + ':' + merge_uname_index2, murlname, merge_format_normal_1)
            worksheet_data_statistics.merge_range(merge_time_index1 + ':' + merge_time_index2, cdatetime, merge_format_time)
            worksheet_data_statistics.write(http_code_index, http_code, font_red)


            ###HIDE SHEET#####
        worksheet_data = workbook.add_worksheet('Data_for_Charts')
        worksheet_chart = workbook.add_worksheet('Charts')
        worksheet_data.hide()

        data_all_resouce = []
        resouce_all_ok_list = []
        resouce_all_BLOCKED_list = []
        resouce_all_PAUSED_list = []
        resouce_all_ERROR_list = []
        resouce_all_abnormal_list = []

        headings_all = ['Number','OK','BLOCKED','PAUSED','ERROR','Abnormal']
        sql_cell_contents_all = "select resouce,COUNT(case when status='a' then 1 else null end) as 'OK',COUNT(case when status='b' then 1 else null end) as 'BLOCKED',COUNT(case when status='c' then 1 else null end) as 'PAUSED',COUNT(case when status='d' then 1 else null end) as 'ERROR',COUNT(case when status='e' then 1 else null end) as 'Abnormal' FROM analysisapi where murlname = '"+ murlname +"' group by resouce"
        cursor.execute(sql_cell_contents_all)
        results_get_all = cursor.fetchall()

        row_all_num = 1
        for row_all in results_get_all:
            row_all_num += 1
            # logging.info(row_all_num)
            resouce = row_all[0]
            OK = row_all[1]
            BLOCKED = row_all[2]
            PAUSED = row_all[3]
            ERROR = row_all[4]
            Abnormal = row_all[5]

            data_all_resouce.append(resouce)
            resouce_all_ok_list.append(OK)
            resouce_all_BLOCKED_list.append(BLOCKED)
            resouce_all_PAUSED_list.append(PAUSED)
            resouce_all_ERROR_list.append(ERROR)
            resouce_all_abnormal_list.append(Abnormal)




        data_all = [data_all_resouce,resouce_all_ok_list,resouce_all_BLOCKED_list,resouce_all_PAUSED_list,resouce_all_ERROR_list,resouce_all_abnormal_list]

        worksheet_data.write_row('A1', headings_all, bold)
        worksheet_data.write_column('A2', data_all[0])
        worksheet_data.write_column('B2', data_all[1])
        worksheet_data.write_column('C2', data_all[2])
        worksheet_data.write_column('D2', data_all[3])
        worksheet_data.write_column('E2', data_all[4])
        worksheet_data.write_column('F2', data_all[5])




        chart3 = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
        chart3.add_series({
            # 'name':       '=Data_for_Charts!$C$1',
            'name':       'OK',
            'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
            'values':     '=Data_for_Charts!$B$2:$B$'+str(row_all_num),
            'fill':   {'color': '#3CB371'},
        })


        chart3.add_series({
            # 'name':       '=Data_for_Charts!$B$1',
            'name':       'BLOCKED',
            'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
            'values':     '=Data_for_Charts!$C$2:$C$'+str(row_all_num),
            'fill':   {'color': '#ff9933'},
        })
        chart3.add_series({
            # 'name':       '=Data_for_Charts!$B$1',
            'name':       'PAUSED',
            'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
            'values':     '=Data_for_Charts!$D$2:$D$'+str(row_all_num),
            'fill':   {'color': '#ffbf00'},
        })
        chart3.add_series({
            # 'name':       '=Data_for_Charts!$B$1',
            'name':       'ERROR',
            'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
            'values':     '=Data_for_Charts!$E$2:$E$'+str(row_all_num),
            'fill':   {'color': '#7e0023'},
        })
        chart3.add_series({
            # 'name':       '=Data_for_Charts!$B$1',
            'name':       'Abnormal',
            'categories': '=Data_for_Charts!$A$2:$A$'+str(row_all_num),
            'values':     '=Data_for_Charts!$F$2:$F$'+str(row_all_num),
            'fill':   {'color': '#FF6347'},
        })
        chart3.set_title({
            'name': 'All Scheduler Jobs Statistics Chart',
            'name_font': {'size': 12, 'bold': True},
            'num_font':  {'italic': True, 'size': 7 },
        })

        chart3.set_x_axis({
            'name': 'Scheduler Job itmes',
            'name_font': {'size': 12, 'bold': True},
            'num_font':  {'italic': True, 'size': 7 },
        })

        chart3.set_y_axis({
            'name': 'Status Percentage',
            'name_font': {'size': 12, 'bold': True},
            'num_font':  {'italic': True, 'size': 7 },
        })

        # chart3.set_style(13)
        chart3.set_size({'width': 1090, 'height': 360})
        cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
        worksheet_chart.merge_range('A1:Q1', 'Summary',cell_format_center_bt)
        worksheet_chart.insert_chart('A2', chart3, {'x_offset': 0, 'y_offset': 4})

        #start_y_offet = 160

        if murlname == 'Digital_API_Pro':
            start_y_offet = 246
        else:
            start_y_offet = 0

        worksheet_chart.merge_range('A26:Q26', 'Details', cell_format_center_bt)
        row_all_num += 2
        for resouce_single_val in data_all_resouce:
            row_start_num = row_all_num
            # logging.info(row_start_num)
            data_single_resauce = []
            data_single_mdate = []
            resouce_single_ok_list = []
            resouce_single_BLOCKED_list = []
            resouce_single_PAUSED_list = []
            resouce_single_ERROR_list = []
            resouce_single_abnormal_list = []

            sql_resouce_single = "select resouce,left(cdatetime,10) as mdate,COUNT(case when status='a' then 1 else null end) as 'OK',COUNT(case when status='b' then 1 else null end) as 'BLOCKED',COUNT(case when status='c' then 1 else null end) as 'PAUSED',COUNT(case when status='d' then 1 else null end) as 'ERROR',COUNT(case when status='e' then 1 else null end) as 'Abnormal' FROM analysisapi where resouce = '" + resouce_single_val + "' group by left(cdatetime,10),resouce order by left(cdatetime,10) asc"
            # logging.info("447 "+ sql_resouce_single)
            cursor.execute(sql_resouce_single)
            results_get_single = cursor.fetchall()
            if len(results_get_single) > 0:
                for row_single in results_get_single:
                    mdate_val = row_single[1]
                    OK_val = row_single[2]
                    BLOCKED_val = row_single[3]
                    PAUSED_val = row_single[4]
                    ERROR_val = row_single[5]
                    Abnormal_val = row_single[6]

                    data_single_resauce.append(resouce_single_val)
                    data_single_mdate.append(mdate_val)
                    resouce_single_ok_list.append(OK_val)
                    resouce_single_BLOCKED_list.append(BLOCKED_val)
                    resouce_single_PAUSED_list.append(PAUSED_val)
                    resouce_single_ERROR_list.append(ERROR_val)
                    resouce_single_abnormal_list.append(Abnormal_val)
                    row_all_num += 1

            start_real_num = row_start_num + 1
            data_single_all_tmp = [data_single_resauce,data_single_mdate,resouce_single_ok_list,resouce_single_BLOCKED_list,resouce_single_PAUSED_list,resouce_single_ERROR_list,resouce_single_abnormal_list]
            sheet_column_index_resauce = 'A' + str(start_real_num)
            sheet_column_index_date = 'B' + str(start_real_num)
            sheet_column_index_ok = 'C' + str(start_real_num)
            sheet_column_index_BLOCKED = 'D' + str(start_real_num)
            sheet_column_index_PAUSED = 'E' + str(start_real_num)
            sheet_column_index_ERROR = 'F' + str(start_real_num)
            sheet_column_index_abnormal = 'G' + str(start_real_num)

            worksheet_data.write_column(sheet_column_index_resauce, data_single_all_tmp[0])
            worksheet_data.write_column(sheet_column_index_date, data_single_all_tmp[1])
            worksheet_data.write_column(sheet_column_index_ok, data_single_all_tmp[2])
            worksheet_data.write_column(sheet_column_index_BLOCKED, data_single_all_tmp[3])
            worksheet_data.write_column(sheet_column_index_PAUSED, data_single_all_tmp[4])
            worksheet_data.write_column(sheet_column_index_ERROR, data_single_all_tmp[5])
            worksheet_data.write_column(sheet_column_index_abnormal, data_single_all_tmp[6])
            chart_tmp = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
            chart_tmp.add_series({
                'name':       '=OK',
                'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                'values':     '=Data_for_Charts!$C$'+str(start_real_num)+':$C$'+str(row_all_num),
                'fill':   {'color': '#3CB371'},
            })
            chart_tmp.add_series({
                'name':       '=BLOCKED',
                'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                'values':     '=Data_for_Charts!$D$'+str(start_real_num)+':$D$'+str(row_all_num),
                'fill':   {'color': '#ff9933'},
            })
            chart_tmp.add_series({
                'name':       '=PAUSED',
                'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                'values':     '=Data_for_Charts!$E$'+str(start_real_num)+':$E$'+str(row_all_num),
                'fill':   {'color': '#ffbf00'},
            })
            chart_tmp.add_series({
                'name':       '=ERROR',
                'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                'values':     '=Data_for_Charts!$F$'+str(start_real_num)+':$F$'+str(row_all_num),
                'fill':   {'color': '#7e0023'},
            })
            chart_tmp.add_series({
                'name':       '=Abnormal',
                'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                'values':     '=Data_for_Charts!$G$'+str(start_real_num)+':$G$'+str(row_all_num),
                'fill':   {'color': '#FF6347'},
            })


            chart_tmp.set_title({
                'name': resouce_single_val + ' Chart',
                'name_font': {'size': 12, 'bold': True},
                'num_font':  {'italic': True, 'size': 7 },
            })


            chart_tmp.set_x_axis({
                'name': 'Date',
                'name_font': {'size': 12, 'bold': True},
                'num_font':  {'italic': True, 'size': 7 },
            })

            chart_tmp.set_y_axis({
                'name': 'Status Percentage',
                'name_font': {'size': 12, 'bold': True},
                'num_font':  {'italic': True, 'size': 7 },
            })

            # chart_tmp.set_style(13)
            chart_tmp.set_size({'width': 1090, 'height': 200})
            AX_chart = 'A' + str(start_real_num)
            start_y_offet += 210
            worksheet_chart.insert_chart(AX_chart, chart_tmp, {'x_offset': 0, 'y_offset': start_y_offet})
            


        dict_all = {}
        sql_select_fir = "select distinct(resouce) as dresouce from analysisapi where murlname = '" + murlname + "'"
        numrows = cursor.execute(sql_select_fir)
        result_f = cursor.fetchall()
        if len(result_f) > 0:
            for row_f in result_f:
                rname = row_f[0]
                rname_list = []
                if rname is not None:
                    cursor.close
                    sql_query_single="select cdatetime,resouce,status from analysisapi where resouce='"+ rname +"'"
                    numrows_1 = cursor.execute(sql_query_single)
                    result_sin = cursor.fetchall()

                    if len(result_sin) > 0:
                        for row_sin in result_sin:
                            list_tmp = []
                            cdatetime_sin = row_sin[0]
                            resouce_sin = row_sin[0]
                            status_sin = row_sin[2]
                            if cdatetime_sin is not None and status_sin is not None:
                                list_tmp.append(cdatetime_sin)
                                list_tmp.append(status_sin)
                            rname_list.append(list_tmp)

                dict_all[rname] = rname_list


        disk_all_check = {}
        for k_rname, v_list_all in dict_all.items():
            list_problem_time = []
            if len(v_list_all) == 0:
                list_problem_time = [['No Exception Time']]
            elif len(v_list_all) == 1:
                if v_list_all[0][1] != 'a':
                    list_problem_time.append(v_list_all[0][0])
                    disk_all_check[k_rname]=[1,list_problem_time]
                elif v_list_all[0][1] == 'a':
                    list_problem_time = [['No Exception Time']]
            elif len(v_list_all) == 2:
                if v_list_all[0][1] != v_list_all[1][1]:
                    if v_list_all[0][1] == 'a':
                        list_problem_time.append(v_list_all[1][0])
                        disk_all_check[k_rname]= list_problem_time
                    elif v_list_all[1][1] == 'a':
                        list_problem_time.append(v_list_all[0][0])
                        list_problem_time.append(v_list_all[1][0])

                    else:
                        list_problem_time = [['No Exception Time']]
                        disk_all_check[k_rname]= list_problem_time
                elif v_list_all[0][1] != 'a' and v_list_all[1][1] != 'a':

                    list_problem_time.append(v_list_all[0][0])

                else:
                    list_problem_time = [['No Exception Time']]
            elif len(v_list_all) > 2:
                vlist_len = len(v_list_all)
                x=0
                while x < vlist_len:
                    tmp_time_list=[]
                    problem_time_tmp_start = None
                    problem_time_tmp_end = None
                    tmp_num_check01 = 0
                    if v_list_all[x][1]!='a':
                        problem_time_tmp_start = v_list_all[x][0]
                        tmp_time_list.append(problem_time_tmp_start)
                        tmp_num_check01 = 0
                        while x + tmp_num_check01 + 1 < vlist_len:
                            if v_list_all[x+tmp_num_check01+1][1]=='a' and v_list_all[x+tmp_num_check01][1]!='a':
                                problem_time_tmp_end = v_list_all[x+tmp_num_check01][0]
                                if problem_time_tmp_end != problem_time_tmp_start:
                                    tmp_time_list.append(problem_time_tmp_end)
                                break
                            tmp_num_check01+=1
                    if len(tmp_time_list) > 0:
                        list_problem_time.append(tmp_time_list)
                    tmp_time_list=[]
                    x=x+1+tmp_num_check01
                if len(list_problem_time) < 1:
                    list_problem_time=[['No Exception Time']]
                # logging.info(list_problem_time)
            disk_all_check[k_rname]=list_problem_time




        cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})
        ###############################################
        worksheet_issue  = workbook.add_worksheet('Issue_Statistics')
        worksheet_issue.set_column(0, 0, 70)
        worksheet_issue.write('A1', 'Services', cell_format_f)
        worksheet_issue.set_column(1, 1, 19)
        worksheet_issue.set_column(2, 2, 40)
        worksheet_issue.write('B1', 'Count', cell_format_f)
        worksheet_issue.write('C1', 'Time', cell_format_f)

        cell_format_center = workbook.add_format()
        cell_format_center.set_align('center')
        cell_format_center.set_align('vcenter')

        cell_format_center_v = workbook.add_format()
        cell_format_center_v.set_align('vcenter')
        init_k=2
        v_len_check=2

        check_key_number = 0

        for k, v in disk_all_check.items():
            tmp_v_list_len = len(v)
            if v[0][0] != "No Exception Time":
                check_key_number = check_key_number + 1
            # if isinstance(v[0], list) is False and tmp_v_list_len == 1:
            #     worksheet_issue.write('A'+str(v_len_check), k)
            #     worksheet_issue.write('B'+str(v_len_check),1, cell_format_center)
            #     worksheet_issue.write('C'+str(v_len_check),str(v[0]), cell_format_center)
            #     v_len_check += 1
            # elif v[0][0]=='No Exception Time' and tmp_v_list_len == 1:
            #     worksheet_issue.write('A'+str(v_len_check), k)
            #     worksheet_issue.write('B'+str(v_len_check),0, cell_format_center)
            #     worksheet_issue.write('C'+str(v_len_check),'No Exception Time',cell_format_center)
            #     v_len_check += 1
            # elif v[0][0]!='No Exception Time' and tmp_v_list_len == 1:
            #     worksheet_issue.write('A'+str(v_len_check), k)
            #     worksheet_issue.write('B'+str(v_len_check),1, cell_format_center)
            #     worksheet_issue.write('C'+str(v_len_check),v[0][0], cell_format_center)
            #     v_len_check += 1
            if tmp_v_list_len > 1:
                v_loop_num = 0
                tmp_row_merge = v_len_check

                while v_loop_num < tmp_v_list_len:
                    tmp_list_v = v[v_loop_num]
                    tmp_list_v_len = len(tmp_list_v)
                    # logging.info(tmp_list_v_len)
                    if tmp_list_v_len == 1:
                        worksheet_issue.write('C'+str(v_len_check), str(v[v_loop_num][0]),cell_format_center)
                    if tmp_list_v_len == 2:
                        worksheet_issue.write('C'+str(v_len_check), str(v[v_loop_num][0])+'~'+str(v[v_loop_num][1]),cell_format_center)

                    v_loop_num += 1
                    v_len_check += 1

                tmp_row_nums_merge = tmp_v_list_len
                merge_count_index1 = 'B' + str(tmp_row_merge)
                merge_count_index2 = 'B' + str(tmp_row_merge + tmp_row_nums_merge - 1)
                merge_resouce_index1 = 'A' + str(tmp_row_merge)
                merge_resouce_index2 = 'A' + str(tmp_row_merge + tmp_row_nums_merge - 1)

                worksheet_issue.merge_range(merge_count_index1 + ':' + merge_count_index2, tmp_v_list_len, cell_format_center)
                worksheet_issue.merge_range(merge_resouce_index1 + ':' + merge_resouce_index2, k, cell_format_center_v)

        if check_key_number == 0:
            worksheet_issue.merge_range('A1:C1', "There is no issue this week")

        try:
            workbook.worksheets_objs.sort(key=lambda x: x.name)
            workbook.close()
        except Exception as workbookcloseError:
            logging.error(workbookcloseError)

        fileName_data = base64.b64encode(fileName.getvalue()).decode()
        tmp_dict_att = {}
        tmp_dict_att["@odata.type"] = "#Microsoft.OutlookServices.FileAttachment"
        tmp_dict_att["name"] = fileName_name
        tmp_dict_att["contentBytes"] = fileName_data
        attachments.append(tmp_dict_att)










    fileName_name = 'DS_API_OSM.xlsx'
    fileName = BytesIO()
    fileName.seek(0)
    fileName.truncate(0)
    workbook = xlsxwriter.Workbook(fileName)
    

    bold = workbook.add_format({'bold': 1})
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})
    font_orange = workbook.add_format({'font_color': '#ffa64d'})
    font_red = workbook.add_format({'font_color': '#FF6347'})
    font_green = workbook.add_format({'font_color': '#3CB371'})

    cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})

    merge_format_time = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})

    merge_format_time_normal = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})
    merge_format_normal_1 = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter'})
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
    cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})

    cell_format_center = workbook.add_format()
    cell_format_center.set_align('center')
    cell_format_center.set_align('vcenter')

    cell_format_center_v = workbook.add_format()
    cell_format_center_v.set_align('vcenter')
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})



    curdate = datetime.date.today().strftime("%Y-%m-%d")
    date_7days_ago = (datetime.datetime.now() + timedelta(days=-7)).strftime("%Y-%m-%d")
    row_all_num = 1
    start_y_offet = 230
    worksheet_data = workbook.add_worksheet('Data_for_Charts')
    worksheet_chart = workbook.add_worksheet('Charts')
    worksheet_chart.activate()
    worksheet_data.hide()

    data_all = []
    data_all_resouce = []
    murlname_ok_list = []
    murlname_Abnormal_list = []

    headings_all = ['murl_name', 'OK', 'Abnormal']
    sql_cell_contents_all = "select murl_name,COUNT(case when http_code=200 then 1 else null end) as 'OK',COUNT(case when http_code !=200 then 1 else null end) as 'Abnormal' from monitor_mapi where  cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "' and murl_name in ('OSM-Api-Pro','OSM-Fnc-Pro','DS-Web-Pro') group by murl_name"

    cursor.execute(sql_cell_contents_all)
    results_get_all = cursor.fetchall()
    worksheet_data.write_row('A1', headings_all, bold)
    for row_all in results_get_all:
        row_all_num += 1
        resouce = row_all[0]
        OK = row_all[1]
        Abnormal = row_all[2]
        data_all_resouce.append(resouce)
        murlname_ok_list.append(OK)
        murlname_Abnormal_list.append(Abnormal)
    
    data_all.append(data_all_resouce)
    data_all.append(murlname_ok_list)
    data_all.append(murlname_Abnormal_list)

    worksheet_data.write_column('A2', data_all[0])
    worksheet_data.write_column('B2', data_all[1])
    worksheet_data.write_column('C2', data_all[2])


    chart3 = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
    chart3.add_series({
        # 'name':       '=Data_for_Charts!$C$1',
        'name': 'OK',
        'categories': '=Data_for_Charts!$A$2:$A$' + str(row_all_num),
        'values': '=Data_for_Charts!$B$2:$B$' + str(row_all_num),
        'fill': {'color': '#3CB371'},
    })

    chart3.add_series({
        # 'name':       '=Data_for_Charts!$B$1',
        'name': 'Abnormal',
        'categories': '=Data_for_Charts!$A$2:$A$' + str(row_all_num),
        'values': '=Data_for_Charts!$C$2:$C$' + str(row_all_num),
        'fill': {'color': '#FF6347'},
    })

    chart3.set_title({
        'name': 'All Schedule Jobs Statistics Chart',
        'name_font': {'size': 12, 'bold': True},
        'num_font': {'italic': True, 'size': 7},
    })

    chart3.set_x_axis({
        'name': 'Schedule Job itmes',
        'name_font': {'size': 12, 'bold': True},
        'num_font': {'italic': True, 'size': 7},
    })

    chart3.set_y_axis({
        'name': 'Status Percentage',
        'name_font': {'size': 12, 'bold': True},
        'num_font': {'italic': True, 'size': 7},
    })

    chart3.set_size({'width': 1090, 'height': 360})
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
    worksheet_chart.merge_range('A1:Q1', 'Summary', cell_format_center_bt)
    worksheet_chart.insert_chart('A2', chart3, {'x_offset': 0, 'y_offset': 4})

    row_all_num += 2
    row_start_num = row_all_num
    data_single_resauce = []
    data_single_mdate = []
    resouce_single_ok_list = []
    resouce_single_abnormal_list = []
    sql_resouce_single = "select murl_name,left(cdatetime,10),COUNT(case when http_code=200 then 1 else null end) as 'OK',COUNT(case when http_code !=200 then 1 else null end) as 'Abnormal' from monitor_mapi where cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "' and murl_name in ('OSM-Api-Pro','OSM-Fnc-Pro','DS-Web-Pro') group by murl_name, left(cdatetime,10) order by murl_name asc"
    single_start_num = 1
    
    start_real_num = row_start_num
    single_chart_list = []
    cursor.execute(sql_resouce_single)
    results_get_single = cursor.fetchall()
    single_query_length = len(results_get_single)
    if len(results_get_single) > 0:
        for row_single in results_get_single:
            murlname = row_single[0]
            mdate_val = row_single[1]
            OK_val = row_single[2]
            Abnormal_val = row_single[3]

            if single_start_num > 1:
                if data_single_resauce[-1] != murlname:
                    single_tmp_dict = {}
                    single_tmp_list = []
                    single_tmp_list.append(data_single_resauce)
                    single_tmp_list.append(data_single_mdate)
                    single_tmp_list.append(resouce_single_ok_list)
                    single_tmp_list.append(resouce_single_abnormal_list)



                    tmp_start_num = start_real_num
                    start_real_num = start_real_num + len(data_single_resauce)

                    tmp_start_end_num_list = []
                    tmp_start_end_num_list.append(tmp_start_num)
                    tmp_start_end_num_list.append(start_real_num)
                    single_tmp_list.append(tmp_start_end_num_list)
                    single_tmp_dict[data_single_resauce[-1]] = single_tmp_list
                    single_chart_list.append(single_tmp_dict)


                    data_single_all_tmp = [data_single_resauce, data_single_mdate, resouce_single_ok_list, resouce_single_abnormal_list]
                    sheet_column_index_resauce = 'A' + str(tmp_start_num)
                    sheet_column_index_date = 'B' + str(tmp_start_num)
                    sheet_column_index_ok = 'C' + str(tmp_start_num)
                    sheet_column_index_abnormal = 'D' + str(tmp_start_num)

                    worksheet_data.write_column(sheet_column_index_resauce, data_single_all_tmp[0])
                    worksheet_data.write_column(sheet_column_index_date, data_single_all_tmp[1])
                    worksheet_data.write_column(sheet_column_index_ok, data_single_all_tmp[2])
                    worksheet_data.write_column(sheet_column_index_abnormal, data_single_all_tmp[3])

                    data_single_resauce = []
                    data_single_mdate = []
                    resouce_single_ok_list = []
                    resouce_single_abnormal_list = []
            data_single_resauce.append(murlname)
            data_single_mdate.append(mdate_val)
            resouce_single_ok_list.append(OK_val)
            resouce_single_abnormal_list.append(Abnormal_val)

            if single_start_num == single_query_length:
                single_tmp_dict = {}
                single_tmp_list = []
                single_tmp_list.append(data_single_resauce)
                single_tmp_list.append(data_single_mdate)
                single_tmp_list.append(resouce_single_ok_list)
                single_tmp_list.append(resouce_single_abnormal_list)

                tmp_start_num = start_real_num
                tmp_start_end_num_list = []
                tmp_start_end_num_list.append(tmp_start_num)
                tmp_start_end_num_list.append(start_real_num + len(data_single_resauce))
                single_tmp_list.append(tmp_start_end_num_list)

                single_tmp_dict[data_single_resauce[-1]] = single_tmp_list
                single_chart_list.append(single_tmp_dict)

                start_real_num = start_real_num + len(data_single_resauce)
                data_single_all_tmp = [data_single_resauce, data_single_mdate, resouce_single_ok_list,resouce_single_abnormal_list]
                sheet_column_index_resauce = 'A' + str(tmp_start_num)
                sheet_column_index_date = 'B' + str(tmp_start_num)
                sheet_column_index_ok = 'C' + str(tmp_start_num)
                sheet_column_index_abnormal = 'D' + str(tmp_start_num)

                worksheet_data.write_column(sheet_column_index_resauce, data_single_all_tmp[0])
                worksheet_data.write_column(sheet_column_index_date, data_single_all_tmp[1])
                worksheet_data.write_column(sheet_column_index_ok, data_single_all_tmp[2])
                worksheet_data.write_column(sheet_column_index_abnormal, data_single_all_tmp[3])

            single_start_num += 1

    # logging.info(single_chart_list)

    worksheet_chart.merge_range('A26:Q26', 'Details', cell_format_center_bt)
    if len(single_chart_list) > 0:
        for single_data_dict in single_chart_list:
            for key_sdc, value_sdc in single_data_dict.items():
                if len(value_sdc) > 1:
                    chart_tmp = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
                    start_real_num = value_sdc[-1][0]
                    row_all_num = value_sdc[-1][1] - 1
                    resouce = value_sdc[0][0]
                    chart_tmp.add_series({
                        'name':       '=OK',
                        'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                        'values':     '=Data_for_Charts!$C$'+str(start_real_num)+':$C$'+str(row_all_num),
                        'fill':   {'color': '#3CB371'},
                    })
                    chart_tmp.add_series({
                        'name':       '=Abnormal',
                        'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                        'values':     '=Data_for_Charts!$D$'+str(start_real_num)+':$D$'+str(row_all_num),
                        'fill':   {'color': '#FF6347'},
                    })

                    chart_tmp.set_title({
                        'name': resouce + ' Chart',
                        'name_font': {'size': 12, 'bold': True},
                        'num_font':  {'italic': True, 'size': 7 },
                    })


                    chart_tmp.set_x_axis({
                        'name': 'Date',
                        'name_font': {'size': 12, 'bold': True},
                        'num_font':  {'italic': True, 'size': 7 },
                    })

                    chart_tmp.set_y_axis({
                        'name': 'Status Percentage',
                        'name_font': {'size': 12, 'bold': True},
                        'num_font':  {'italic': True, 'size': 7 },
                    })



                    chart_tmp.set_size({'width': 1090, 'height': 200})
                    AX_chart = 'A' + str(start_real_num)
                    start_y_offet += 210
                    worksheet_chart.insert_chart(AX_chart, chart_tmp, {'x_offset': 0, 'y_offset': start_y_offet})

    worksheet_dataStatistics = workbook.add_worksheet('Data_Statistics')
    bold = workbook.add_format({'bold': 1})
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})
    font_orange = workbook.add_format({'font_color': '#ffa64d'})
    font_red = workbook.add_format({'font_color': '#FF6347'})
    font_green = workbook.add_format({'font_color': '#3CB371'})

    cell_format_f = workbook.add_format( {'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 12,'bg_color': '#B4C6E7'})


    

    merge_format_time = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})

    merge_format_time_normal = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})
    merge_format_normal_1 = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter'})
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
    

    cell_format_center = workbook.add_format()
    cell_format_center.set_align('center')
    cell_format_center.set_align('vcenter')

    cell_format_center_v = workbook.add_format()
    cell_format_center_v.set_align('vcenter')
    



    curdate = datetime.date.today().strftime("%Y-%m-%d")
    curdate_1 = (datetime.datetime.now() + timedelta(days=-1)).strftime("%Y-%m-%d")
    start_date_time = datetime.datetime.strptime(date_7days_ago, '%Y-%m-%d')
    end_date_time = datetime.datetime.strptime(curdate_1, '%Y-%m-%d')
    worksheet_dataStatistics.set_column(0, 0, 36)
    worksheet_dataStatistics.set_row(0, 20)
    row_nums_start = 0

    if start_date_time != end_date_time:
        worksheet_dataStatistics.set_column(0, 0, 70)
        worksheet_dataStatistics.write('A1', 'Services', cell_format_f)
        m = 0
        n = 0
        sheet_col = 0
        while m == 0:
            date_cur_tmp = start_date_time + timedelta(days=n)
            if date_cur_tmp == end_date_time:
                m = 1
            end_char_num = 66 + n
            sheet_index_f1 = chr(end_char_num) + str('1')
            sheet_val_f1 = date_cur_tmp.strftime('%Y-%m-%d')
            if date_cur_tmp <= end_date_time:
                worksheet_dataStatistics.set_column(n + 1, n + 1, 19)
                worksheet_dataStatistics.write(sheet_index_f1, sheet_val_f1, cell_format_f)
                # sql_cell_contents = "select b.res," + "'" + sheet_val_f1 + "',ifnull(a.OK,0),ifnull(a.Abnormal,0) from (select murl_name,left(cdatetime,10) as mdate,COUNT(IF(http_code=200,1, NULL)) as 'OK',COUNT(IF(http_code!=200,1, NULL)) as 'Abnormal' FROM monitor_mapi where cdatetime like " + "'" + sheet_val_f1 + "%' group by mdate,murl_name order by mdate asc) a right join  (select distinct(murl_name) as res from monitor_mapi) b  on b.res = a.murl_name"

                sql_cell_contents = "select b.res," + "'" + sheet_val_f1 + "'as cdate,ISNULL(a.OK,0) as OK,ISNULL(a.Abnormal,0) as Abnormal from (select murl_name,left(cdatetime,10) as mdate,COUNT(case when http_code=200 then 1 else null end) as 'OK',COUNT(case when http_code != 200 then 1 else null end) as 'Abnormal' FROM monitor_mapi where cdatetime like" + "'" + sheet_val_f1 + "%' group by left(cdatetime,10),murl_name) a right join (select distinct(murl_name) as res from monitor_mapi where murl_name in ('DS-Web-Pro','OSM-Api-Pro','OSM-Fnc-Pro') and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "') b  on b.res = a.murl_name order by b.res"




                cursor.execute(sql_cell_contents)
                results_get_cont = cursor.fetchall()
                sheet_row = 1
                for row in results_get_cont:
                    resouce = row[0]
                    resouce_OK = resouce + '_OK'
                    resouce_Abnormal = resouce + '_Abnormal'
                    mdate = row[1]
                    OK = row[2]
                    Abnormal = row[3]

                    sheet_index_sum_start = chr(end_char_num) + str(sheet_row + 1)
                    sheet_index_sum_end = chr(end_char_num) + str(sheet_row + 2)

                    if n == 0:
                        worksheet_dataStatistics.write_string(sheet_row, sheet_col, resouce_OK, font_green)
                        worksheet_dataStatistics.write_string(sheet_row + 1, sheet_col, resouce_Abnormal, font_red)
                        worksheet_dataStatistics.write_string(sheet_row + 2, sheet_col, 'Sum')
                        worksheet_dataStatistics.write_number(sheet_row, sheet_col + 1, OK)
                        worksheet_dataStatistics.write_number(sheet_row + 1, sheet_col + 1, Abnormal, font_red)

                    else:
                        worksheet_dataStatistics.write_number(sheet_row, sheet_col + 1, OK)
                        worksheet_dataStatistics.write_number(sheet_row + 1, sheet_col + 1, Abnormal, font_red)

                    worksheet_dataStatistics.write(sheet_row + 2, sheet_col + 1, '=SUM(' + sheet_index_sum_start + ':' + sheet_index_sum_end + ')')
                    sheet_row += 4
                    row_nums_start = sheet_row
                row_nums_start += 1

                exception_sql = "select isnull(count(*),0) as n200nums from monitor_mapi where http_code != 200 and left(cdatetime,10) = '" + sheet_val_f1 + "' and murl_name in ('DS-Web-Pro','OSM-Api-Pro','OSM-Fnc-Pro')"

                cursor.execute(exception_sql)
                exception_all = cursor.fetchall()
                for row_exceptions in exception_all:
                    exception_num = row_exceptions[0]
                    if sheet_col < 1:
                        worksheet_dataStatistics.write_string(row_nums_start, sheet_col, 'Exception Error', font_red)
                        worksheet_dataStatistics.write_number(row_nums_start, sheet_col + 1, exception_num, font_red)
                    else:
                        worksheet_dataStatistics.write_number(row_nums_start, sheet_col + 1, exception_num, font_red)


                sheet_col += 1
            n = n+1

    row_nums_start += 3
    mulr_index = 'A' + str(row_nums_start)
    merge_uname_index1 = 'B' + str(row_nums_start)
    merge_uname_index2 = 'C' + str(row_nums_start)
    merge_time_index1 = 'D' + str(row_nums_start)
    merge_time_index2 = 'E' + str(row_nums_start)
    http_code_index = 'F' + str(row_nums_start)
    worksheet_dataStatistics.write(mulr_index, 'URL', cell_format_f)
    worksheet_dataStatistics.merge_range(merge_uname_index1 + ':' + merge_uname_index2, 'URL_Name',cell_format_f)
    worksheet_dataStatistics.merge_range(merge_time_index1 + ':' + merge_time_index2, 'Date_Time',cell_format_f)
    worksheet_dataStatistics.write(http_code_index, 'Http_Code', cell_format_f)

    merge_format_time = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})

    merge_format_time_normal = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})
    merge_format_normal_1 = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter'})

    sql_check_http_code = "select a.murl_name,a.cdatetime, a.http_code,b.murl from monitor_mapi a, monitor_apiconfig b where a.http_code != 200 and a.cdatetime >= '" + date_7days_ago + "' and a.cdatetime < '" + curdate + "' and a.murl_name = b.murl_name and a.murl_name in ('DS-Web-Pro','OSM-Api-Pro','OSM-Fnc-Pro')"


    cursor.execute(sql_check_http_code)
    results_http_code = cursor.fetchall()
    if row_nums_start < 1:
        row_nums_start = 1
    if len(results_http_code) > 0:
        for row_http_code in results_http_code:
            row_nums_start += 1

            murl_name = row_http_code[0]
            cdatetime = row_http_code[1]
            http_code = row_http_code[2]
            murl = row_http_code[3]

            murl_index = 'A' + str(row_nums_start)
            merge_uname_index1 = 'B' + str(row_nums_start)
            merge_uname_index2 = 'C' + str(row_nums_start)

            merge_time_index1 = 'D' + str(row_nums_start)
            merge_time_index2 = 'E' + str(row_nums_start)
            http_code_index = 'F' + str(row_nums_start)

            worksheet_dataStatistics.write(murl_index, murl, font_red)
            worksheet_dataStatistics.merge_range(merge_uname_index1 + ':' + merge_uname_index2, murlname, merge_format_normal_1)
            worksheet_dataStatistics.merge_range(merge_time_index1 + ':' + merge_time_index2, cdatetime, merge_format_time)
            worksheet_dataStatistics.write(http_code_index, http_code, font_red)
    

    dict_all = {}
    sql_select_fir = "select distinct(murl_name) as dresouce from monitor_mapi where cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "' and murl_name in ('DS-Web-Pro','OSM-Api-Pro','OSM-Fnc-Pro')"
    print(sql_select_fir)
    # print(sql_select_fir)
    cursor.execute(sql_select_fir)
    numrows = cursor.fetchall()
    print(numrows)
    if len(numrows) > 0:
        result_f = cursor.fetchall()
        for row_f in result_f:
            rname = row_f[0]
            rname_list = []
            if rname is not None:
                cursor.close
                sql_query_single="select cdatetime,murl_name,api_status from monitor_mapi where murl_name='"+ rname +"' and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "' and murl_name in ('DS-Web-Pro','OSM-Api-Pro','OSM-Fnc-Pro')"
                # print(sql_query_single)
                numrows_1 = cursor.execute(sql_query_single)
                if numrows_1 > 0:
                    result_sin = cursor.fetchall()
                    for row_sin in result_sin:
                        list_tmp = []
                        cdatetime_sin = row_sin[0]
                        resouce_sin = row_sin[0]
                        status_sin = row_sin[2]
                        if cdatetime_sin is not None and status_sin is not None:
                            list_tmp.append(cdatetime_sin)
                            list_tmp.append(status_sin)
                        rname_list.append(list_tmp)

            dict_all[rname] = rname_list

    print(dict_all)
    disk_all_check = {}
    for k_rname, v_list_all in dict_all.items():
        list_problem_time = []
        if len(v_list_all) == 0:
            list_problem_time = [['No Exception Time']]
        elif len(v_list_all) == 1:
            if v_list_all[0][1] != 1:
                list_problem_time.append(v_list_all[0][0])
                disk_all_check[k_rname]=[1,list_problem_time]
            elif v_list_all[0][1] == 1:
                list_problem_time = [['No Exception Time']]
        elif len(v_list_all) == 2:
            if v_list_all[0][1] != v_list_all[1][1]:
                if v_list_all[0][1] == 1:
                    list_problem_time.append(v_list_all[1][0])
                    disk_all_check[k_rname]= list_problem_time
                elif v_list_all[1][1] == 1:
                    list_problem_time.append(v_list_all[0][0])
                    list_problem_time.append(v_list_all[1][0])

                else:
                    list_problem_time = [['No Exception Time']]
                    disk_all_check[k_rname]= list_problem_time
            elif v_list_all[0][1] != 1 and v_list_all[1][1] != 1:

                list_problem_time.append(v_list_all[0][0])

            else:
                list_problem_time = [['No Exception Time']]
        elif len(v_list_all) > 2:
            vlist_len = len(v_list_all)
            x = 0
            while x < vlist_len:
                tmp_time_list = []
                problem_time_tmp_start = None
                problem_time_tmp_end = None
                tmp_num_check01 = 0
                if v_list_all[x][1] != 1:
                    problem_time_tmp_start = v_list_all[x][0]
                    tmp_time_list.append(problem_time_tmp_start)
                    tmp_num_check01 = 0
                    while x + tmp_num_check01 + 1 < vlist_len:
                        if v_list_all[x+tmp_num_check01+1][1]==1 and v_list_all[x+tmp_num_check01][1]!=1:
                            problem_time_tmp_end = v_list_all[x+tmp_num_check01][0]
                            if problem_time_tmp_end != problem_time_tmp_start:
                                tmp_time_list.append(problem_time_tmp_end)
                            break
                        tmp_num_check01+=1
                if len(tmp_time_list) > 0:
                    list_problem_time.append(tmp_time_list)
                tmp_time_list=[]
                x=x+1+tmp_num_check01
            if len(list_problem_time) < 1:
                list_problem_time=[['No Exception Time']]
            # print(list_problem_time)
        disk_all_check[k_rname] = list_problem_time





    worksheet_issue  = workbook.add_worksheet('Issue_Statistics')
    worksheet_issue.set_column(0, 0, 70)
    worksheet_issue.write('A1', 'Services', cell_format_f)
    worksheet_issue.set_column(1, 1, 19)
    worksheet_issue.set_column(2, 2, 40)
    worksheet_issue.write('B1', 'Count', cell_format_f)
    worksheet_issue.write('C1', 'Time', cell_format_f)

    cell_format_center = workbook.add_format()
    cell_format_center.set_align('center')
    cell_format_center.set_align('vcenter')

    cell_format_center_v = workbook.add_format()
    cell_format_center_v.set_align('vcenter')
    init_k = 2
    v_len_check = 2


    check_key_number = 0
    for k, v in disk_all_check.items():
        tmp_v_list_len = len(v)
        # print("###v####")
        # print(tmp_v_list_len)
        # print(k)
        # print(v)
        # print(v[0][0])
        if v[0][0] != "No Exception Time":
            check_key_number = check_key_number + 1
        # if isinstance(v[0], list) is False and tmp_v_list_len == 1:
        #     worksheet_issue.write('A' + str(v_len_check), k)
        #     worksheet_issue.write('B' + str(v_len_check), 1, cell_format_center)
        #     worksheet_issue.write('C' + str(v_len_check), str(v[0]), cell_format_center)
        #     v_len_check += 1
        # elif v[0][0] == 'No Exception Time' and tmp_v_list_len == 1:
        #     worksheet_issue.write('A' + str(v_len_check), k)
        #     worksheet_issue.write('B' + str(v_len_check), 0, cell_format_center)
        #     worksheet_issue.write('C' + str(v_len_check), 'No Exception Time', cell_format_center)
        #     v_len_check += 1
        if v[0][0] != 'No Exception Time' and tmp_v_list_len == 1:
            worksheet_issue.write('A' + str(v_len_check), k)
            worksheet_issue.write('B' + str(v_len_check), 1, cell_format_center)
            worksheet_issue.write('C' + str(v_len_check), str(v[0][0]), cell_format_center)
            v_len_check += 1
        if tmp_v_list_len > 1:
            v_loop_num = 0
            tmp_row_merge = v_len_check

            while v_loop_num < tmp_v_list_len:
                tmp_list_v = v[v_loop_num]
                tmp_list_v_len = len(tmp_list_v)
                # print(tmp_list_v_len)
                if tmp_list_v_len == 1:
                    worksheet_issue.write('C' + str(v_len_check), str(v[v_loop_num][0]), cell_format_center)
                if tmp_list_v_len == 2:
                    worksheet_issue.write('C' + str(v_len_check), str(v[v_loop_num][0]) + '~' + str(v[v_loop_num][1]), cell_format_center)

                v_loop_num += 1
                v_len_check += 1

            tmp_row_nums_merge = tmp_v_list_len
            merge_count_index1 = 'B' + str(tmp_row_merge)
            merge_count_index2 = 'B' + str(tmp_row_merge + tmp_row_nums_merge - 1)
            merge_resouce_index1 = 'A' + str(tmp_row_merge)
            merge_resouce_index2 = 'A' + str(tmp_row_merge + tmp_row_nums_merge - 1)

            worksheet_issue.merge_range(merge_count_index1 + ':' + merge_count_index2, tmp_v_list_len, cell_format_center)
            worksheet_issue.merge_range(merge_resouce_index1 + ':' + merge_resouce_index2, k, cell_format_center_v)

    # print(check_key_number)
    if check_key_number == 0:
        worksheet_issue.merge_range('A1:C1', "There is no issue this week")

    try:
        workbook.worksheets_objs.sort(key=lambda x: x.name)
        workbook.close()
    except Exception as workbookcloseError:
        logging.error(workbookcloseError)



    fileName_data = base64.b64encode(fileName.getvalue()).decode()
    tmp_dict_att = {}
    tmp_dict_att["@odata.type"] = "#Microsoft.OutlookServices.FileAttachment"
    tmp_dict_att["name"] = fileName_name
    tmp_dict_att["contentBytes"] = fileName_data
    attachments.append(tmp_dict_att)

    #########################################################Web Job######################################################################################################################################

    fileName_name = 'WebJob_API_All.xlsx'
    fileName = BytesIO()
    fileName.seek(0)
    fileName.truncate(0)
    workbook = xlsxwriter.Workbook(fileName)
    

    bold = workbook.add_format({'bold': 1})
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})
    font_orange = workbook.add_format({'font_color': '#ffa64d'})
    font_red = workbook.add_format({'font_color': '#FF6347'})
    font_green = workbook.add_format({'font_color': '#3CB371'})

    cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})

    merge_format_time = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})

    merge_format_time_normal = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})
    merge_format_normal_1 = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter'})
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
    cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})

    cell_format_center = workbook.add_format()
    cell_format_center.set_align('center')
    cell_format_center.set_align('vcenter')

    cell_format_center_v = workbook.add_format()
    cell_format_center_v.set_align('vcenter')
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})



    curdate = datetime.date.today().strftime("%Y-%m-%d")
    date_7days_ago = (datetime.datetime.now() + timedelta(days=-7)).strftime("%Y-%m-%d")
    row_all_num = 1
    start_y_offet = 230
    worksheet_data = workbook.add_worksheet('Data_for_Charts')
    worksheet_chart = workbook.add_worksheet('Charts')
    worksheet_chart.activate()
    worksheet_data.hide()

    data_all = []
    data_all_resouce = []
    murlname_ok_list = []
    murlname_Abnormal_list = []

    headings_all = ['[WebJobName]', 'OK', 'Abnormal']
    sql_cell_contents_all = "select webjobName,COUNT(case when othernote=1 then 1 else null end) as 'OK',COUNT(case when othernote = 0 then 1 else null end) as 'Abnormal' from monitor_webjob where  cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "' group by webjobName"

    cursor.execute(sql_cell_contents_all)
    results_get_all = cursor.fetchall()
    worksheet_data.write_row('A1', headings_all, bold)
    for row_all in results_get_all:
        row_all_num += 1
        resouce = row_all[0]
        OK = row_all[1]
        Abnormal = row_all[2]
        data_all_resouce.append(resouce)
        murlname_ok_list.append(OK)
        murlname_Abnormal_list.append(Abnormal)
    
    data_all.append(data_all_resouce)
    data_all.append(murlname_ok_list)
    data_all.append(murlname_Abnormal_list)

    worksheet_data.write_column('A2', data_all[0])
    worksheet_data.write_column('B2', data_all[1])
    worksheet_data.write_column('C2', data_all[2])


    chart3 = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
    chart3.add_series({
        # 'name':       '=Data_for_Charts!$C$1',
        'name': 'OK',
        'categories': '=Data_for_Charts!$A$2:$A$' + str(row_all_num),
        'values': '=Data_for_Charts!$B$2:$B$' + str(row_all_num),
        'fill': {'color': '#3CB371'},
    })

    chart3.add_series({
        # 'name':       '=Data_for_Charts!$B$1',
        'name': 'Abnormal',
        'categories': '=Data_for_Charts!$A$2:$A$' + str(row_all_num),
        'values': '=Data_for_Charts!$C$2:$C$' + str(row_all_num),
        'fill': {'color': '#FF6347'},
    })

    chart3.set_title({
        'name': 'All Schedule Jobs Statistics Chart',
        'name_font': {'size': 12, 'bold': True},
        'num_font': {'italic': True, 'size': 7},
    })

    chart3.set_x_axis({
        'name': 'Schedule Job itmes',
        'name_font': {'size': 12, 'bold': True},
        'num_font': {'italic': True, 'size': 7},
    })

    chart3.set_y_axis({
        'name': 'Status Percentage',
        'name_font': {'size': 12, 'bold': True},
        'num_font': {'italic': True, 'size': 7},
    })

    chart3.set_size({'width': 1090, 'height': 360})
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
    worksheet_chart.merge_range('A1:Q1', 'Summary', cell_format_center_bt)
    worksheet_chart.insert_chart('A2', chart3, {'x_offset': 0, 'y_offset': 4})

    row_all_num += 2
    row_start_num = row_all_num
    data_single_resauce = []
    data_single_mdate = []
    resouce_single_ok_list = []
    resouce_single_abnormal_list = []
    sql_resouce_single = "select webjobName,left(cdatetime,10),COUNT(case when othernote=1 then 1 else null end) as 'OK',COUNT(case when othernote = 0 then 1 else null end) as 'Abnormal' from monitor_webjob where cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "' group by webjobName, left(cdatetime,10) order by webjobName asc"
    single_start_num = 1
    
    start_real_num = row_start_num
    single_chart_list = []
    cursor.execute(sql_resouce_single)
    results_get_single = cursor.fetchall()
    single_query_length = len(results_get_single)
    if len(results_get_single) > 0:
        for row_single in results_get_single:
            murlname = row_single[0]
            mdate_val = row_single[1]
            OK_val = row_single[2]
            Abnormal_val = row_single[3]

            if single_start_num > 1:
                if data_single_resauce[-1] != murlname:
                    single_tmp_dict = {}
                    single_tmp_list = []
                    single_tmp_list.append(data_single_resauce)
                    single_tmp_list.append(data_single_mdate)
                    single_tmp_list.append(resouce_single_ok_list)
                    single_tmp_list.append(resouce_single_abnormal_list)



                    tmp_start_num = start_real_num
                    start_real_num = start_real_num + len(data_single_resauce)

                    tmp_start_end_num_list = []
                    tmp_start_end_num_list.append(tmp_start_num)
                    tmp_start_end_num_list.append(start_real_num)
                    single_tmp_list.append(tmp_start_end_num_list)
                    single_tmp_dict[data_single_resauce[-1]] = single_tmp_list
                    single_chart_list.append(single_tmp_dict)


                    data_single_all_tmp = [data_single_resauce, data_single_mdate, resouce_single_ok_list, resouce_single_abnormal_list]
                    sheet_column_index_resauce = 'A' + str(tmp_start_num)
                    sheet_column_index_date = 'B' + str(tmp_start_num)
                    sheet_column_index_ok = 'C' + str(tmp_start_num)
                    sheet_column_index_abnormal = 'D' + str(tmp_start_num)

                    worksheet_data.write_column(sheet_column_index_resauce, data_single_all_tmp[0])
                    worksheet_data.write_column(sheet_column_index_date, data_single_all_tmp[1])
                    worksheet_data.write_column(sheet_column_index_ok, data_single_all_tmp[2])
                    worksheet_data.write_column(sheet_column_index_abnormal, data_single_all_tmp[3])

                    data_single_resauce = []
                    data_single_mdate = []
                    resouce_single_ok_list = []
                    resouce_single_abnormal_list = []
            data_single_resauce.append(murlname)
            data_single_mdate.append(mdate_val)
            resouce_single_ok_list.append(OK_val)
            resouce_single_abnormal_list.append(Abnormal_val)

            if single_start_num == single_query_length:
                single_tmp_dict = {}
                single_tmp_list = []
                single_tmp_list.append(data_single_resauce)
                single_tmp_list.append(data_single_mdate)
                single_tmp_list.append(resouce_single_ok_list)
                single_tmp_list.append(resouce_single_abnormal_list)

                tmp_start_num = start_real_num
                tmp_start_end_num_list = []
                tmp_start_end_num_list.append(tmp_start_num)
                tmp_start_end_num_list.append(start_real_num + len(data_single_resauce))
                single_tmp_list.append(tmp_start_end_num_list)

                single_tmp_dict[data_single_resauce[-1]] = single_tmp_list
                single_chart_list.append(single_tmp_dict)

                start_real_num = start_real_num + len(data_single_resauce)
                data_single_all_tmp = [data_single_resauce, data_single_mdate, resouce_single_ok_list,resouce_single_abnormal_list]
                sheet_column_index_resauce = 'A' + str(tmp_start_num)
                sheet_column_index_date = 'B' + str(tmp_start_num)
                sheet_column_index_ok = 'C' + str(tmp_start_num)
                sheet_column_index_abnormal = 'D' + str(tmp_start_num)

                worksheet_data.write_column(sheet_column_index_resauce, data_single_all_tmp[0])
                worksheet_data.write_column(sheet_column_index_date, data_single_all_tmp[1])
                worksheet_data.write_column(sheet_column_index_ok, data_single_all_tmp[2])
                worksheet_data.write_column(sheet_column_index_abnormal, data_single_all_tmp[3])

            single_start_num += 1

    # logging.info(single_chart_list)

    worksheet_chart.merge_range('A26:Q26', 'Details', cell_format_center_bt)
    if len(single_chart_list) > 0:
        for single_data_dict in single_chart_list:
            for key_sdc, value_sdc in single_data_dict.items():
                if len(value_sdc) > 1:
                    chart_tmp = workbook.add_chart({'type': 'column', 'subtype': 'percent_stacked'})
                    start_real_num = value_sdc[-1][0]
                    row_all_num = value_sdc[-1][1] - 1
                    resouce = value_sdc[0][0]
                    chart_tmp.add_series({
                        'name':       '=OK',
                        'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                        'values':     '=Data_for_Charts!$C$'+str(start_real_num)+':$C$'+str(row_all_num),
                        'fill':   {'color': '#3CB371'},
                    })
                    chart_tmp.add_series({
                        'name':       '=Abnormal',
                        'categories': '=Data_for_Charts!$B$'+str(start_real_num)+':$B$'+str(row_all_num),
                        'values':     '=Data_for_Charts!$D$'+str(start_real_num)+':$D$'+str(row_all_num),
                        'fill':   {'color': '#FF6347'},
                    })

                    chart_tmp.set_title({
                        'name': resouce + ' Chart',
                        'name_font': {'size': 12, 'bold': True},
                        'num_font':  {'italic': True, 'size': 7 },
                    })


                    chart_tmp.set_x_axis({
                        'name': 'Date',
                        'name_font': {'size': 12, 'bold': True},
                        'num_font':  {'italic': True, 'size': 7 },
                    })

                    chart_tmp.set_y_axis({
                        'name': 'Status Percentage',
                        'name_font': {'size': 12, 'bold': True},
                        'num_font':  {'italic': True, 'size': 7 },
                    })



                    chart_tmp.set_size({'width': 1090, 'height': 200})
                    AX_chart = 'A' + str(start_real_num)
                    start_y_offet += 210
                    worksheet_chart.insert_chart(AX_chart, chart_tmp, {'x_offset': 0, 'y_offset': start_y_offet})

    worksheet_dataStatistics = workbook.add_worksheet('Data_Statistics')
    bold = workbook.add_format({'bold': 1})
    date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})
    font_orange = workbook.add_format({'font_color': '#ffa64d'})
    font_red = workbook.add_format({'font_color': '#FF6347'})
    font_green = workbook.add_format({'font_color': '#3CB371'})

    cell_format_f = workbook.add_format( {'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 12,'bg_color': '#B4C6E7'})


    

    merge_format_time = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})

    merge_format_time_normal = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})
    merge_format_normal_1 = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter'})
    cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
    

    cell_format_center = workbook.add_format()
    cell_format_center.set_align('center')
    cell_format_center.set_align('vcenter')

    cell_format_center_v = workbook.add_format()
    cell_format_center_v.set_align('vcenter')
    



    curdate = datetime.date.today().strftime("%Y-%m-%d")
    curdate_1 = (datetime.datetime.now() + timedelta(days=-1)).strftime("%Y-%m-%d")
    start_date_time = datetime.datetime.strptime(date_7days_ago, '%Y-%m-%d')
    end_date_time = datetime.datetime.strptime(curdate_1, '%Y-%m-%d')
    worksheet_dataStatistics.set_column(0, 0, 36)
    worksheet_dataStatistics.set_row(0, 20)
    row_nums_start = 0

    if start_date_time != end_date_time:
        worksheet_dataStatistics.set_column(0, 0, 70)
        worksheet_dataStatistics.write('A1', 'Services', cell_format_f)
        m = 0
        n = 0
        sheet_col = 0
        while m == 0:
            date_cur_tmp = start_date_time + timedelta(days=n)
            if date_cur_tmp == end_date_time:
                m = 1
            end_char_num = 66 + n
            sheet_index_f1 = chr(end_char_num) + str('1')
            sheet_val_f1 = date_cur_tmp.strftime('%Y-%m-%d')
            if date_cur_tmp <= end_date_time:
                worksheet_dataStatistics.set_column(n + 1, n + 1, 19)
                worksheet_dataStatistics.write(sheet_index_f1, sheet_val_f1, cell_format_f)
                # sql_cell_contents = "select b.res," + "'" + sheet_val_f1 + "',ifnull(a.OK,0),ifnull(a.Abnormal,0) from (select murl_name,left(cdatetime,10) as mdate,COUNT(IF(http_code=200,1, NULL)) as 'OK',COUNT(IF(http_code!=200,1, NULL)) as 'Abnormal' FROM monitor_mapi where cdatetime like " + "'" + sheet_val_f1 + "%' group by mdate,murl_name order by mdate asc) a right join  (select distinct(murl_name) as res from monitor_mapi) b  on b.res = a.murl_name"

                # sql_cell_contents = "select b.res," + "'" + sheet_val_f1 + "'as cdate,ISNULL(a.OK,0) as OK,ISNULL(a.Abnormal,0) as Abnormal from (select murl_name,left(cdatetime,10) as mdate,COUNT(case when http_code=200 then 1 else null end) as 'OK',COUNT(case when http_code != 200 then 1 else null end) as 'Abnormal' FROM monitor_mapi where cdatetime like" + "'" + sheet_val_f1 + "%' group by left(cdatetime,10),murl_name) a right join (select distinct(murl_name) as res from monitor_mapi where murl_name in ('DS-Web-Pro','OSM-Api-Pro','OSM-Fnc-Pro') and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "') b  on b.res = a.murl_name order by b.res"

                sql_cell_contents = "select b.res," + "'" + sheet_val_f1 + "'as cdate,ISNULL(a.OK,0) as OK,ISNULL(a.Abnormal,0) as Abnormal from (select webjobName,left(cdatetime,10) as mdate,COUNT(case when othernote=1 then 1 else null end) as 'OK',COUNT(case when othernote = 0 then 1 else null end) as 'Abnormal' FROM monitor_webjob where cdatetime like" + "'" + sheet_val_f1 + "%' group by left(cdatetime,10),webjobName) a right join (select distinct(webjobName) as res from monitor_webjob where cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "') b  on b.res = a.webjobName order by b.res"




                cursor.execute(sql_cell_contents)
                results_get_cont = cursor.fetchall()
                sheet_row = 1
                for row in results_get_cont:
                    resouce = row[0]
                    resouce_OK = resouce + '_OK'
                    resouce_Abnormal = resouce + '_Abnormal'
                    mdate = row[1]
                    OK = row[2]
                    Abnormal = row[3]

                    sheet_index_sum_start = chr(end_char_num) + str(sheet_row + 1)
                    sheet_index_sum_end = chr(end_char_num) + str(sheet_row + 2)

                    if n == 0:
                        worksheet_dataStatistics.write_string(sheet_row, sheet_col, resouce_OK, font_green)
                        worksheet_dataStatistics.write_string(sheet_row + 1, sheet_col, resouce_Abnormal, font_red)
                        worksheet_dataStatistics.write_string(sheet_row + 2, sheet_col, 'Sum')
                        worksheet_dataStatistics.write_number(sheet_row, sheet_col + 1, OK)
                        worksheet_dataStatistics.write_number(sheet_row + 1, sheet_col + 1, Abnormal, font_red)

                    else:
                        worksheet_dataStatistics.write_number(sheet_row, sheet_col + 1, OK)
                        worksheet_dataStatistics.write_number(sheet_row + 1, sheet_col + 1, Abnormal, font_red)

                    worksheet_dataStatistics.write(sheet_row + 2, sheet_col + 1, '=SUM(' + sheet_index_sum_start + ':' + sheet_index_sum_end + ')')
                    sheet_row += 4
                    row_nums_start = sheet_row
                row_nums_start += 1

                exception_sql = "select isnull(count(*),0) as n200nums from monitor_webjob where othernote = 0 and left(cdatetime,10) = '" + sheet_val_f1 + "'"

                cursor.execute(exception_sql)
                exception_all = cursor.fetchall()
                for row_exceptions in exception_all:
                    exception_num = row_exceptions[0]
                    if sheet_col < 1:
                        worksheet_dataStatistics.write_string(row_nums_start, sheet_col, 'Exception Error', font_red)
                        worksheet_dataStatistics.write_number(row_nums_start, sheet_col + 1, exception_num, font_red)
                    else:
                        worksheet_dataStatistics.write_number(row_nums_start, sheet_col + 1, exception_num, font_red)


                sheet_col += 1
            n = n+1

    row_nums_start += 3
    mulr_index = 'A' + str(row_nums_start)
    merge_uname_index1 = 'B' + str(row_nums_start)
    merge_uname_index2 = 'C' + str(row_nums_start)
    merge_time_index1 = 'D' + str(row_nums_start)
    merge_time_index2 = 'E' + str(row_nums_start)
    http_code_index = 'F' + str(row_nums_start)
    worksheet_dataStatistics.write(mulr_index, 'URL', cell_format_f)
    worksheet_dataStatistics.merge_range(merge_uname_index1 + ':' + merge_uname_index2, 'URL_Name',cell_format_f)
    worksheet_dataStatistics.merge_range(merge_time_index1 + ':' + merge_time_index2, 'Date_Time',cell_format_f)
    worksheet_dataStatistics.write(http_code_index, 'Http_Code', cell_format_f)

    merge_format_time = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})

    merge_format_time_normal = workbook.add_format({
        'align': 'center',
        'valign': 'vcenter',
        'num_format': 'yyyy-mm-dd hh:mm:ss'})
    merge_format_normal_1 = workbook.add_format({
        'font_color': '#FF6347',
        'align': 'center',
        'valign': 'vcenter'})

    sql_check_http_code = "select a.webjobName,a.cdatetime, a.othernote,b.sites from monitor_webjob a, monitor_webjobConfig b where a.othernote = 0 and a.cdatetime >= '" + date_7days_ago + "' and a.cdatetime < '" + curdate + "' and a.webjobName = b.webjobName"


    cursor.execute(sql_check_http_code)
    results_http_code = cursor.fetchall()
    if row_nums_start < 1:
        row_nums_start = 1
    if len(results_http_code) > 0:
        for row_http_code in results_http_code:
            row_nums_start += 1

            murl_name = row_http_code[0]
            cdatetime = row_http_code[1]
            http_code = row_http_code[2]
            murl = row_http_code[3]

            murl_index = 'A' + str(row_nums_start)
            merge_uname_index1 = 'B' + str(row_nums_start)
            merge_uname_index2 = 'C' + str(row_nums_start)

            merge_time_index1 = 'D' + str(row_nums_start)
            merge_time_index2 = 'E' + str(row_nums_start)
            http_code_index = 'F' + str(row_nums_start)

            worksheet_dataStatistics.write(murl_index, murl, font_red)
            worksheet_dataStatistics.merge_range(merge_uname_index1 + ':' + merge_uname_index2, murlname, merge_format_normal_1)
            worksheet_dataStatistics.merge_range(merge_time_index1 + ':' + merge_time_index2, cdatetime, merge_format_time)
            worksheet_dataStatistics.write(http_code_index, http_code, font_red)
    

    dict_all = {}
    sql_select_fir = "select distinct(webjobName) as dresouce from monitor_webjob where cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "'"
    print(sql_select_fir)
    # print(sql_select_fir)
    cursor.execute(sql_select_fir)
    numrows = cursor.fetchall()
    print(numrows)
    if len(numrows) > 0:
        result_f = cursor.fetchall()
        for row_f in result_f:
            rname = row_f[0]
            rname_list = []
            if rname is not None:
                cursor.close
                sql_query_single="select cdatetime,webjobName,othernote from monitor_webjob where webjobName='"+ rname +"' and cdatetime >= '" + date_7days_ago + "' and cdatetime < '" + curdate + "'"
                # print(sql_query_single)
                numrows_1 = cursor.execute(sql_query_single)
                if numrows_1 > 0:
                    result_sin = cursor.fetchall()
                    for row_sin in result_sin:
                        list_tmp = []
                        cdatetime_sin = row_sin[0]
                        resouce_sin = row_sin[0]
                        status_sin = row_sin[2]
                        if cdatetime_sin is not None and status_sin is not None:
                            list_tmp.append(cdatetime_sin)
                            list_tmp.append(status_sin)
                        rname_list.append(list_tmp)

            dict_all[rname] = rname_list

    print(dict_all)
    disk_all_check = {}
    for k_rname, v_list_all in dict_all.items():
        list_problem_time = []
        if len(v_list_all) == 0:
            list_problem_time = [['No Exception Time']]
        elif len(v_list_all) == 1:
            if v_list_all[0][1] != 1:
                list_problem_time.append(v_list_all[0][0])
                disk_all_check[k_rname]=[1,list_problem_time]
            elif v_list_all[0][1] == 1:
                list_problem_time = [['No Exception Time']]
        elif len(v_list_all) == 2:
            if v_list_all[0][1] != v_list_all[1][1]:
                if v_list_all[0][1] == 1:
                    list_problem_time.append(v_list_all[1][0])
                    disk_all_check[k_rname]= list_problem_time
                elif v_list_all[1][1] == 1:
                    list_problem_time.append(v_list_all[0][0])
                    list_problem_time.append(v_list_all[1][0])

                else:
                    list_problem_time = [['No Exception Time']]
                    disk_all_check[k_rname]= list_problem_time
            elif v_list_all[0][1] != 1 and v_list_all[1][1] != 1:

                list_problem_time.append(v_list_all[0][0])

            else:
                list_problem_time = [['No Exception Time']]
        elif len(v_list_all) > 2:
            vlist_len = len(v_list_all)
            x = 0
            while x < vlist_len:
                tmp_time_list = []
                problem_time_tmp_start = None
                problem_time_tmp_end = None
                tmp_num_check01 = 0
                if v_list_all[x][1] != 1:
                    problem_time_tmp_start = v_list_all[x][0]
                    tmp_time_list.append(problem_time_tmp_start)
                    tmp_num_check01 = 0
                    while x + tmp_num_check01 + 1 < vlist_len:
                        if v_list_all[x+tmp_num_check01+1][1]==1 and v_list_all[x+tmp_num_check01][1]!=1:
                            problem_time_tmp_end = v_list_all[x+tmp_num_check01][0]
                            if problem_time_tmp_end != problem_time_tmp_start:
                                tmp_time_list.append(problem_time_tmp_end)
                            break
                        tmp_num_check01+=1
                if len(tmp_time_list) > 0:
                    list_problem_time.append(tmp_time_list)
                tmp_time_list=[]
                x=x+1+tmp_num_check01
            if len(list_problem_time) < 1:
                list_problem_time=[['No Exception Time']]
            # print(list_problem_time)
        disk_all_check[k_rname] = list_problem_time






    worksheet_issue  = workbook.add_worksheet('Issue_Statistics')
    worksheet_issue.set_column(0, 0, 70)
    worksheet_issue.write('A1', 'Services', cell_format_f)
    worksheet_issue.set_column(1, 1, 19)
    worksheet_issue.set_column(2, 2, 40)
    worksheet_issue.write('B1', 'Count', cell_format_f)
    worksheet_issue.write('C1', 'Time', cell_format_f)

    cell_format_center = workbook.add_format()
    cell_format_center.set_align('center')
    cell_format_center.set_align('vcenter')

    cell_format_center_v = workbook.add_format()
    cell_format_center_v.set_align('vcenter')
    init_k = 2
    v_len_check = 2


    check_key_number = 0
    for k, v in disk_all_check.items():
        tmp_v_list_len = len(v)
        # print("###v####")
        # print(tmp_v_list_len)
        # print(k)
        # print(v)
        # print(v[0][0])
        if v[0][0] != "No Exception Time":
            check_key_number = check_key_number + 1
        # if isinstance(v[0], list) is False and tmp_v_list_len == 1:
        #     worksheet_issue.write('A' + str(v_len_check), k)
        #     worksheet_issue.write('B' + str(v_len_check), 1, cell_format_center)
        #     worksheet_issue.write('C' + str(v_len_check), str(v[0]), cell_format_center)
        #     v_len_check += 1
        # elif v[0][0] == 'No Exception Time' and tmp_v_list_len == 1:
        #     worksheet_issue.write('A' + str(v_len_check), k)
        #     worksheet_issue.write('B' + str(v_len_check), 0, cell_format_center)
        #     worksheet_issue.write('C' + str(v_len_check), 'No Exception Time', cell_format_center)
        #     v_len_check += 1
        if v[0][0] != 'No Exception Time' and tmp_v_list_len == 1:
            worksheet_issue.write('A' + str(v_len_check), k)
            worksheet_issue.write('B' + str(v_len_check), 1, cell_format_center)
            worksheet_issue.write('C' + str(v_len_check), str(v[0][0]), cell_format_center)
            v_len_check += 1
        if tmp_v_list_len > 1:
            v_loop_num = 0
            tmp_row_merge = v_len_check

            while v_loop_num < tmp_v_list_len:
                tmp_list_v = v[v_loop_num]
                tmp_list_v_len = len(tmp_list_v)
                # print(tmp_list_v_len)
                if tmp_list_v_len == 1:
                    worksheet_issue.write('C' + str(v_len_check), str(v[v_loop_num][0]), cell_format_center)
                if tmp_list_v_len == 2:
                    worksheet_issue.write('C' + str(v_len_check), str(v[v_loop_num][0]) + '~' + str(v[v_loop_num][1]), cell_format_center)

                v_loop_num += 1
                v_len_check += 1

            tmp_row_nums_merge = tmp_v_list_len
            merge_count_index1 = 'B' + str(tmp_row_merge)
            merge_count_index2 = 'B' + str(tmp_row_merge + tmp_row_nums_merge - 1)
            merge_resouce_index1 = 'A' + str(tmp_row_merge)
            merge_resouce_index2 = 'A' + str(tmp_row_merge + tmp_row_nums_merge - 1)

            worksheet_issue.merge_range(merge_count_index1 + ':' + merge_count_index2, tmp_v_list_len, cell_format_center)
            worksheet_issue.merge_range(merge_resouce_index1 + ':' + merge_resouce_index2, k, cell_format_center_v)

    # print(check_key_number)
    if check_key_number == 0:
        worksheet_issue.merge_range('A1:C1', "There is no issue this week")

    try:
        workbook.worksheets_objs.sort(key=lambda x: x.name)
        workbook.close()
    except Exception as workbookcloseError:
        logging.error(workbookcloseError)

    fileName_data = base64.b64encode(fileName.getvalue()).decode()
    tmp_dict_att = {}
    tmp_dict_att["@odata.type"] = "#Microsoft.OutlookServices.FileAttachment"
    tmp_dict_att["name"] = fileName_name
    tmp_dict_att["contentBytes"] = fileName_data
    attachments.append(tmp_dict_att)

    #######################################################################################################################################################################################################



    
    def sp_perforce(subscription_id,resource_group_name,TENANT_ID,CLIENT,KEY,datetimeFrom,datetimeEnd):
        url = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/v2.0/token"
        payload = {'client_id': '7bc73e5d-3ad5-4af6-b51b-0ed84b503f7b',
        'refresh_token': 'AQABAAAAAABeAFzDwllzTYGDLh_qYbH8wnYueyYFzEra31Tfg3Xt7qF73tJrBQsx6AxvFzITf1pKXJzPCtsREc8KnJilwUR69-5djnhJExR0UKFc7w45DrB5Fs397uIOgv7E3ZhDB6lJwUGR8LV_seo5ebg8DNVp9Mur0Yz2JqycgXVTOmXa6HuJaeIlGO32sbKz33EmFBeQij88WT0qgVeHakqi1_-ZVEmrTcEYSCf4KG07uOl944cQ_TiAQiTmdMr3ptxhXUhLC4T0m1IplloF6NnPl-VyKoD2ZCG3LjhIVi7Z7MmXqfGtmHgJ5o_uAufnPika11vAkZvFb5e8ebg5WGZ57u_-_mQi2F7HtOEfyc7zyeG-MyWSeXYsFRJPjCKIeQcRzqvLUp9SScedN7DXJylvwlsielDfP4kn6lKNiDW_ctObWwF1HzvODceyGLtjPLvbagpGeTLq5p3e6Pll5g-DCL3AcX0wJ8Ozd9Dje60RlCET5JdaOBU4pqqze-9LlWR5TSq17ZNKbKiPMaROEEAyRkqiBT53yJBKal4XxxzJl7UdEar5SgxsS3pM_0FDbk9CDJKPThLvgUAu8EW3dCDsCvWKs19ilp1YOM63w5IwFSNy9-Q4flIeQP-kCS9xOrJsit_MHRF4JwOoNz3HZeyQuH_vL0uYtxZmYGO1vjmrbFhYQtCxe2C8BATqM6VkDgUVSlVOTrY_VPUiWBRVYzxwaWfwuxFWE8I5yxKyKPacCoKxvONR4O53DN0v0ryaAGa3qc7h2Frn9B2tM4pyR9r8xBWFJtmtlCHIOyYTV0jlkyITAyKz1cDtcH0Lool4OUDIyPFROemu6LjIfzdJsftOUi24lHxrP7M7gdJITIWdxLlhHm1_3Ri-RYiVwFfAIZBWzpqp2RzphXqucVcFPp112QznMD3bG4xwT8O_BE0D-zv8kR1OEiXoDT0YND8pRJDY2nx8lPxsLQR9dVQTt5wt_ZqY8dVAy1LpZGkY6NwWCZoAv-guT3R1bXQw6K6_CS-BhDtM1JDlHLtU8vOQUG1tPeszEXPO_GAHnjlMiqqKoRcvQmge6YeV_oJcJU188OEatdPIAd152jBSUcSg-wLUXD6BWlaNK8wOdeBI0rz0vFS6B0hPNb0ZyAXe834oNdqEaJPIvLNIslxGSYHevb-xxYf7IAA',
        'redirect_uri': 'http://localhost:8080',
        'grant_type': 'refresh_token',
        'client_secret': '/X98jkS_0TZ6L:GRDp.xfWNqA/9aKtPO'
        }
        headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
        }
        headers = None
        response_token_r = None
        try:
            response_token = requests.request("POST", url, data = payload)
            respone_token_text = response_token.text
            respone_token_tojson = json.loads(respone_token_text)
            response_token_r = respone_token_tojson["access_token"]
            token_head_val = "Bearer "+ response_token_r
            headers = {'Authorization': token_head_val}

        except Exception as get_token_error:
            print(get_token_error)

        sp_list = []
        murl = "https://management.azure.com/subscriptions/" +subscription_id+ "/resourceGroups/" +resource_group_name+ "/providers/Microsoft.Web/serverfarms?api-version=2018-02-01"
        try:
            response_getV = requests.request("GET", murl, headers=headers)
            response_value = response_getV.text
            
            check_result_value = json.loads(response_value)
            
            check_result_list = check_result_value["value"]
            for i in check_result_list:
                sp_list.append(i['name'])
        except Exception as get_response_error:
            print(get_token_error)


        len_sp = len(sp_list)
        start_num = 2
        start_y_offet = 0
        start_row_chart = 1
        fileName = BytesIO()
        fileName.seek(0)
        fileName.truncate(0)
        workbook = xlsxwriter.Workbook(fileName)

        # workbook = xlsxwriter.Workbook(excelFileName)
        worksheet_cpu_mem_data = workbook.add_worksheet('Data_Statistics')
        worksheet_chart = workbook.add_worksheet('Charts')
        worksheet_chart.activate()
        # worksheet_cpu_mem_data.hide()
        cell_format_f = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 12, 'bg_color':'#B4C6E7'})
        cell_format_midd = workbook.add_format({'bold': True, 'align': 'center', 'valign': 'vcenter', 'font_name': 'Times New Roman','font_size': 11})
        cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
        worksheet_cpu_mem_data.set_column(0, 0, 36)
        worksheet_cpu_mem_data.set_column(1, 5, 27)
        worksheet_cpu_mem_data.set_row(0,20)
        worksheet_cpu_mem_data.write('A1', 'ResourceName',cell_format_f)
        worksheet_cpu_mem_data.write('B1', 'DateTime',cell_format_f)
        worksheet_cpu_mem_data.write('C1', 'CPU Percentage Average',cell_format_f)
        worksheet_cpu_mem_data.write('D1', 'CPU Percentage Max',cell_format_f)
        worksheet_cpu_mem_data.write('E1', 'Mem Percentage Average',cell_format_f)
        worksheet_cpu_mem_data.write('F1', 'Mem Percentage Max',cell_format_f)
        worksheet_chart.merge_range('A1:Q1', 'Digital Suit CPU_Mem Summary',cell_format_center_bt)
        if len_sp > 0:
            for sp_name in sp_list:
                resource_id = (
                    "subscriptions/{}/"
                    "resourceGroups/{}/"
                    "providers/Microsoft.Web/serverfarms/{}"
                ).format(subscription_id, resource_group_name, sp_name)
                credentials = ServicePrincipalCredentials(
                    client_id = CLIENT,
                    secret = KEY,
                    tenant = TENANT_ID
                )
                client = MonitorManagementClient(
                    credentials,
                    subscription_id
                )
                metrics_data_cpu_av = client.metrics.list(
                    resource_id,
                    timespan=datetimeFrom + "/" + datetimeEnd,
                    interval='PT15M',
                    metricnames = 'CpuPercentage',
                    aggregation='Average'
                )
                metrics_data_cpu_max = client.metrics.list(
                    resource_id,
                    timespan=datetimeFrom + "/" + datetimeEnd,
                    interval='PT15M',
                    metricnames = 'CpuPercentage',
                    aggregation='Maximum'
                )

                metrics_data_mem_av = client.metrics.list(
                    resource_id,
                    timespan=datetimeFrom + "/" + datetimeEnd,
                    interval='PT15M',
                    metricnames = 'MemoryPercentage',
                    aggregation='Average'
                )

                metrics_data_mem_max = client.metrics.list(
                    resource_id,
                    timespan=datetimeFrom + "/" + datetimeEnd,
                    interval='PT15M',
                    metricnames = 'MemoryPercentage',
                    aggregation='Maximum'
                )

                data_list_cpu_av = []
                data_list_mem_av = []
                data_list_cpu_max = []
                data_list_mem_max = []

                for item in metrics_data_cpu_av.value:
                    for timeserie in item.timeseries:
                        for data in timeserie.data:
                            dtime = data.time_stamp
                            avori = data.average
                            if avori is not None:
                                tmp_list = []
                                dtime_ = dtime + timedelta(hours=8)
                                tmp_list.append(dtime_.strftime('%Y-%m-%d %H:%M:%S'))
                                tmp_list.append(format(avori,'0.2f'))
                                data_list_cpu_av.append(tmp_list)
                for item in metrics_data_cpu_max.value:
                    for timeserie in item.timeseries:
                        for data in timeserie.data:
                            dtime = data.time_stamp
                            avori = data.maximum
                            if avori is not None:
                                tmp_list = []
                                dtime_ = dtime + timedelta(hours=8)
                                tmp_list.append(dtime_.strftime('%Y-%m-%d %H:%M:%S'))
                                tmp_list.append(format(avori,'0.2f'))
                                data_list_cpu_max.append(tmp_list)


                for item in metrics_data_mem_av.value:
                    for timeserie in item.timeseries:
                        for data in timeserie.data:
                            dtime = data.time_stamp
                            avori = data.average
                            if avori is not None:
                                tmp_list = []
                                dtime_ = dtime + timedelta(hours=8)
                                tmp_list.append(dtime_.strftime('%Y-%m-%d %H:%M:%S'))
                                tmp_list.append(format(avori,'0.2f'))
                                data_list_mem_av.append(tmp_list)

                for item in metrics_data_mem_max.value:
                    for timeserie in item.timeseries:
                        for data in timeserie.data:
                            dtime = data.time_stamp
                            avori = data.maximum
                            if avori is not None:
                                tmp_list = []
                                dtime_ = dtime + timedelta(hours=8)
                                tmp_list.append(dtime_.strftime('%Y-%m-%d %H:%M:%S'))
                                tmp_list.append(format(avori,'0.2f'))
                                data_list_mem_max.append(tmp_list)



                Date_List = []
                Cpu_datalist_av = []
                Mem_datalist_av = []
                Cpu_datalist_max = []
                Mem_datalist_max = []



                len_data = len(data_list_cpu_av)
                if len_data > 0:
                    for x in range(len_data):
                        Date_List.append(data_list_cpu_av[x][0])
                        Cpu_datalist_av.append(float(data_list_cpu_av[x][1]))
                        Mem_datalist_av.append(float(data_list_mem_av[x][1]))
                        Cpu_datalist_max.append(float(data_list_cpu_max[x][1]))
                        Mem_datalist_max.append(float(data_list_mem_max[x][1]))

                row_num = len(Cpu_datalist_av)
                resouce = sp_name
                row_all_num = start_num + row_num - 1
                # worksheet_cpu_mem_data.write_column('A'+ str(start_num), resouce)
                worksheet_cpu_mem_data.merge_range('A' + str(start_num) + ':A' + str(row_all_num), resouce,cell_format_midd)
                
                worksheet_cpu_mem_data.write_column('B'+ str(start_num), Date_List)
                worksheet_cpu_mem_data.write_column('C'+ str(start_num), Cpu_datalist_av)
                worksheet_cpu_mem_data.write_column('D'+ str(start_num), Cpu_datalist_max)
                worksheet_cpu_mem_data.write_column('E'+ str(start_num), Mem_datalist_av)
                worksheet_cpu_mem_data.write_column('F'+ str(start_num), Mem_datalist_max)

                
                chart_tmp = workbook.add_chart({'type': 'line'})

                chart_tmp.add_series({
                    'name':       'CPU Percentage-Average',
                    'categories': '=Data_Statistics!$B$'+str(start_num)+':$B$'+str(row_all_num),
                    'values':     '=Data_Statistics!$C$'+str(start_num)+':$C$'+str(row_all_num),
                    'fill':   {'color': '#00FF00'},
                })
                chart_tmp.add_series({
                    'name':       'CPU Percentage-Max',
                    'categories': '=Data_Statistics!$B$'+str(start_num)+':$B$'+str(row_all_num),
                    'values':     '=Data_Statistics!$D$'+str(start_num)+':$D$'+str(row_all_num),
                    'fill':   {'color': '#008000'},
                })

                chart_tmp.add_series({
                    'name':       'Mem Percentage-Average',
                    'categories': '=Data_Statistics!$B$'+str(start_num)+':$B$'+str(row_all_num),
                    'values':     '=Data_Statistics!$E$'+str(start_num)+':$E$'+str(row_all_num),
                    'fill':   {'color': '#FF00FF'},
                })
                chart_tmp.add_series({
                    'name':       'Mem Percentage-Max',
                    'categories': '=Data_Statistics!$B$'+str(start_num)+':$B$'+str(row_all_num),
                    'values':     '=Data_Statistics!$F$'+str(start_num)+':$F$'+str(row_all_num),
                    'fill':   {'color': '#800080'},
                })


                # chart_tmp.set_size({'width': 1090, 'height': 360})
                # cell_format_center_bt = workbook.add_format({'bold': True, 'align': 'left', 'valign': 'vcenter', 'font_name': 'Times New Roman', 'font_size': 16})
                # worksheet_chart.merge_range('A1:Q1', 'CPU_Mem',cell_format_center_bt)
                # worksheet_chart.insert_chart('A2', chart3, {'x_offset': 0, 'y_offset': 4})

                chart_tmp.set_title({
                    'name': resouce + ' Chart',
                    'name_font': {'size': 12, 'bold': True},
                    'num_font':  {'italic': True, 'size': 7 },
                })


                chart_tmp.set_x_axis({
                    'name': 'Date',
                    'name_font': {'size': 12, 'bold': False},
                    'num_font':  {'italic': True, 'size': 7 },
                })

                chart_tmp.set_y_axis({
                    'name': 'Usage Percentage',
                    'name_font': {'size': 12, 'bold': True},
                    'num_font':  {'italic': True, 'size': 7 },
                })



                # chart_tmp.set_size({'width': 2048, 'height': 400})
                chart_tmp.set_size({'width': 1999, 'height': 360})
                AX_chart = 'A' + str(start_row_chart)
                worksheet_chart.insert_chart(AX_chart, chart_tmp, {'x_offset': 0, 'y_offset': 40})
                start_row_chart = start_row_chart + 20
                start_y_offet += 40
                start_num = start_num + row_num


        try:
            workbook.close()
        except Exception as workbookcloseError:
            logging.error(workbookcloseError)
        fileName_data = base64.b64encode(fileName.getvalue()).decode()
        tmp_dict_att = {}
        tmp_dict_att["@odata.type"] = "#Microsoft.OutlookServices.FileAttachment"
        tmp_dict_att["name"] = fileName_name
        tmp_dict_att["contentBytes"] = fileName_data
        attachments.append(tmp_dict_att)


        


    fileName_name = 'ProductSuit_Prd_CPU_Mem.xlsx'


    TENANT_ID = '4f6e1565-c2c7-43cb-8a4c-0981d022ce20'
    CLIENT = '36541daf-7f29-456d-a130-09b382b02989'
    KEY = 'b0+EtQRNZ2FpOfKIQHygnWq6Pe0fJbagNTzVQzhCemY='
    subscription_id = "197ea515-467a-49c1-a634-3b6a106ddf0a"
    resource_group_name = "productsuite-prd-aue-rg"
    # sp_name = "osm-api-prd-aue-sp"

    # datetimeEnd = (datetime.datetime.now()).strftime("%Y-%m-%d %H:%M:%S")
    # datetimeFrom = (datetime.datetime.now() + timedelta(days = -7)).strftime("%Y-%m-%d %H:%M:%S")

    datetimeEnd = (datetime.datetime.now()).strftime("%Y-%m-%d")
    datetimeFrom = (datetime.datetime.now() + timedelta(days = -7)).strftime("%Y-%m-%d")

    sp_perforce(subscription_id,resource_group_name,TENANT_ID,CLIENT,KEY,datetimeFrom,datetimeEnd)







    # mailto_ori = "yuanshuai668@126.com;yuanshuai9916@gmail.com;michael.yuan@bhp.com"
    mailto_ori = 'leo.wang@bhp.com;binghua.wu@bhp.com;charles.liu@bhp.com;tianhong.zhao@bhp.com;chunbin.tang@bhp.com;gabriella.wu@bhp.com;MCCSupportTeam@bhpbilliton.com;DL-TECH-SHA-MCCDevOps@bhpbilliton.com'
    mail_subject = 'Weekly API-Health-Check data Statistics'
    mail_content = "<b>Hi All</b><p> The attachments are API-Health-Check weekly data Statistics, please review.<br><br> <font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br>Best Regards!</br>  <b>MCC Release and Support Team</b>"
    fsendnamail( mailto_ori,mail_subject,mail_content,attachments )

    cnxn.close()