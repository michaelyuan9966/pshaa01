import datetime
import logging
from exchangelib import DELEGATE, Account, Credentials, Configuration, Message, HTMLBody
import azure.functions as func
import os


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)


    emailusername=os.environ["emailusername"]
    emailpassword=os.environ["emailpassword"]
    emailhost=os.environ["emailhost"]
    credentials = Credentials(username=emailusername, password=emailpassword)
    config = Configuration(server=emailhost, credentials=credentials)
    account = Account(primary_smtp_address=emailusername, config=config,autodiscover=False, access_type=DELEGATE)

    mail_subject = "send to michal"
    mail_content = "please know it </br> let us try again"
    mailto_high = ["michael.yuan@bhp.com"]

    try:
        m = Message(account=account,subject=mail_subject,body = HTMLBody(mail_content),to_recipients=mailto_high)
        m.send()
    except Exception as mailsenderror:
        logging.error(mailsenderror)
        


