import requests
import json
import datetime
from datetime import timedelta
import sys
import pyodbc
import os
import logging

from ..mail.smailfunc import fsendamail
from ..mail.smailfunc import fsendmail
from ..mail.smailfunc import fsendnamail

def webJobFunc( subscriptions,resourceGroups,sites,webjobName ):
    server_sql = "healthcheck-dev-sgp-sql.database.windows.net"
    database_sql = "healthcheck-dev-sgp-db"
    username_sql = "bhpadmin"
    password_sql = "Devops2019"
    driver_sql = "{ODBC Driver 17 for SQL Server}"


    mailto_high = "leo.wang@bhp.com;binghua.wu@bhp.com;michael.yuan@bhp.com"
    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")

    try:
        cnxn = pyodbc.connect('DRIVER='+driver_sql+';SERVER='+server_sql+';PORT=1433;DATABASE='+database_sql+';UID='+username_sql+';PWD='+ password_sql)
        cursor = cnxn.cursor()
    except Exception as error_sql_con:
        print(error_sql_con)
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        mail_subject = "[Critical]: DataBase_Connect Error: " + database_sql
        mail_content = 'Dear'  + '<p>' + 'The DataBase of '+ database_sql + ' could not be connected, please check.<br>Detail error: ' + str(error_sql_con) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
        sys.exit(1)



    url = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/v2.0/token"
    payload = {'client_id': '7bc73e5d-3ad5-4af6-b51b-0ed84b503f7b',
    'refresh_token': 'AQABAAAAAABeAFzDwllzTYGDLh_qYbH8wnYueyYFzEra31Tfg3Xt7qF73tJrBQsx6AxvFzITf1pKXJzPCtsREc8KnJilwUR69-5djnhJExR0UKFc7w45DrB5Fs397uIOgv7E3ZhDB6lJwUGR8LV_seo5ebg8DNVp9Mur0Yz2JqycgXVTOmXa6HuJaeIlGO32sbKz33EmFBeQij88WT0qgVeHakqi1_-ZVEmrTcEYSCf4KG07uOl944cQ_TiAQiTmdMr3ptxhXUhLC4T0m1IplloF6NnPl-VyKoD2ZCG3LjhIVi7Z7MmXqfGtmHgJ5o_uAufnPika11vAkZvFb5e8ebg5WGZ57u_-_mQi2F7HtOEfyc7zyeG-MyWSeXYsFRJPjCKIeQcRzqvLUp9SScedN7DXJylvwlsielDfP4kn6lKNiDW_ctObWwF1HzvODceyGLtjPLvbagpGeTLq5p3e6Pll5g-DCL3AcX0wJ8Ozd9Dje60RlCET5JdaOBU4pqqze-9LlWR5TSq17ZNKbKiPMaROEEAyRkqiBT53yJBKal4XxxzJl7UdEar5SgxsS3pM_0FDbk9CDJKPThLvgUAu8EW3dCDsCvWKs19ilp1YOM63w5IwFSNy9-Q4flIeQP-kCS9xOrJsit_MHRF4JwOoNz3HZeyQuH_vL0uYtxZmYGO1vjmrbFhYQtCxe2C8BATqM6VkDgUVSlVOTrY_VPUiWBRVYzxwaWfwuxFWE8I5yxKyKPacCoKxvONR4O53DN0v0ryaAGa3qc7h2Frn9B2tM4pyR9r8xBWFJtmtlCHIOyYTV0jlkyITAyKz1cDtcH0Lool4OUDIyPFROemu6LjIfzdJsftOUi24lHxrP7M7gdJITIWdxLlhHm1_3Ri-RYiVwFfAIZBWzpqp2RzphXqucVcFPp112QznMD3bG4xwT8O_BE0D-zv8kR1OEiXoDT0YND8pRJDY2nx8lPxsLQR9dVQTt5wt_ZqY8dVAy1LpZGkY6NwWCZoAv-guT3R1bXQw6K6_CS-BhDtM1JDlHLtU8vOQUG1tPeszEXPO_GAHnjlMiqqKoRcvQmge6YeV_oJcJU188OEatdPIAd152jBSUcSg-wLUXD6BWlaNK8wOdeBI0rz0vFS6B0hPNb0ZyAXe834oNdqEaJPIvLNIslxGSYHevb-xxYf7IAA',
    'redirect_uri': 'http://localhost:8080',
    'grant_type': 'refresh_token',
    'client_secret': '/X98jkS_0TZ6L:GRDp.xfWNqA/9aKtPO'
    }
    headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
    }


    headers = None
    response_token_r = None
    try:
        response_token = requests.request("POST", url, data = payload)
        respone_token_text = response_token.text
        respone_token_tojson = json.loads(respone_token_text)
        response_token_r = respone_token_tojson["access_token"]
        token_head_val = "Bearer "+ response_token_r
        headers = {'Authorization': token_head_val}
        # print(headers)
        # logging.info("Head:" + str(headers))

    except Exception as get_token_error:
        print(get_token_error)
        # logging.error("DSApi_Get_Token Error: ################" + str(get_token_error) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]: DSApi_Get_Token"
        mail_content = 'Dear'  + '<p>' + 'DSApi_Get_Token erorr, please check.<br>Detail error: ' + str(get_token_error) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( mailto_high,mail_subject,mail_content )
        sys.exit(1)

    # "https://management.azure.com/subscriptions/197ea515-467a-49c1-a634-3b6a106ddf0a/resourceGroups/productsuite-prd-aue-rg/providers/Microsoft.Web/sites/osm-webjob-prd-aue-web/triggeredwebjobs?api-version=2018-02-01"


    # webjob_url_list = []

    murl = "https://management.azure.com/subscriptions/" +subscriptions+ "/resourceGroups/" +resourceGroups+ "/providers/Microsoft.Web/sites/" +sites+ "/triggeredwebjobs?api-version=2018-02-01"
    print(murl)
    try:
        response_getV = requests.request("GET", murl, headers=headers)
    except Exception as get_response_error:
        print(get_token_error)
        mail_subject = "[Critical]: Get Webjob Request error, WebjobName: " +  webjobName
        mail_content = 'Dear'  + '<p>' + ' Get Webjob Request error, WebjobName, please check.<br>Detail error: ' + str(get_response_error) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( mailto_high,mail_subject,mail_content )
        othernote = 0
        http_code = 6200
        sql_insert = "insert into monitor_webjoburl(webjob_url,http_code,cdatetime,othernote) values('%s',%d,'%s',%d)"%(murl,http_code,hours_8hours_later,othernote)
        cursor.execute(sql_insert)
        cursor.commit()

        status = 'Exception'
        othernote = 0
        sql_insert_1 = "insert into monitor_webjob(webjobName,status,cdatetime,othernote) values('%s','%s','%s',%d)"%(webjobName,status,hours_8hours_later,othernote)
        cursor.execute(sql_insert_1)
        cnxn.commit()
        sys.exit(1)

    if murl is not None:
        http_code = response_getV.status_code
        response_value = response_getV.text
        sql_lastcheck = "SELECT top(1) webjob_url,http_code,othernote FROM monitor_webjoburl where webjob_url = '" + murl +"' order by id desc"
        http_code_lastcheck = 200
        cursor.execute(sql_lastcheck)
        table_lastcheck = cursor.fetchall()
        if len(table_lastcheck) > 0:
            for row_lastcheck in table_lastcheck:
                if row_lastcheck is not None:
                    http_code_lastcheck = int(row_lastcheck[1])

            
        if http_code != 200 and http_code != http_code_lastcheck:
            othernote = 0
            mail_subject = '[Critical]' + murl + ' HTTP_CODE: ' + str(http_code)
            mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' is ' + str(http_code) +'. Please check it.<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
            fsendmail( mailto_high,mail_subject,mail_content )
            sql_insert = "insert into monitor_webjoburl(webjob_url,http_code,cdatetime,othernote) values('%s',%d,'%s',%d)"%(murl,http_code,hours_8hours_later,othernote)
            # logging.info(sql_insert)
            cursor.execute(sql_insert)
            cursor.commit()
            # logging.info('Head log:' + str(headers))
                        
        if http_code == 200 and http_code != http_code_lastcheck:
            othernote = 1
            mail_subject = '[Critical]Resume: ' + murl + ' resume well. Now HTTP_CODE: ' + str(http_code)
            mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' HTTP_CODE is ' + str(http_code) +'. Resume well.<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
            fsendmail( mailto_high,mail_subject,mail_content )

            sql_insert = "insert into monitor_webjoburl(webjob_url,http_code,cdatetime,othernote) values('%s',%d,'%s',%d)"%(murl,http_code,hours_8hours_later,othernote)
            # logging.info(sql_insert)
            cursor.execute(sql_insert)
            cursor.commit()

        if http_code == 200 and http_code_lastcheck == 200:
            othernote = 1
            sql_insert = "insert into monitor_webjoburl(webjob_url,http_code,cdatetime,othernote) values('%s',%d,'%s',%d)"%(murl,http_code,hours_8hours_later,othernote)
            print(sql_insert)
            # logging.info(sql_insert)
            cursor.execute(sql_insert)
            cursor.commit()
            check_result_value = json.loads(response_value)
            check_result_list = check_result_value["value"]

            print(check_result_list)
            for webjob_dict in check_result_list:
                if webjob_dict["properties"]["latest_run"] is not None:
                    webjobName_webquery = webjob_dict["properties"]["name"]
                    if webjobName_webquery == webjobName:
                        status = webjob_dict["properties"]["latest_run"]["status"]
                        othernote = 0
                        if status.lower() == "success":
                            othernote = 1

                        if othernote == 0:
                            mail_subject = "[Critical]: WebjobName: " +  webjobName + " Status:" + status
                            mail_content = 'Dear'  + '<p>' + ' The Webjob +'+ webjobName +' current status is '+ status + ', please check.<br><br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                            fsendmail( mailto_high,mail_subject,mail_content )


                        if othernote == 1:
                            sql_lastcheck_webjob = "SELECT top(1) webjobName,status,othernote FROM monitor_webjob where webjobName = '" + webjobName +"' order by id desc"
                            cursor.execute(sql_lastcheck_webjob)
                            webjob_lastcheck = cursor.fetchall()
                            if len(webjob_lastcheck) > 0:
                                for row_webjob in webjob_lastcheck:
                                    othernote_last = row_webjob[2]
                                    if othernote_last == 0:
                                        mail_subject = '[Critical]Resume webjob: ' + webjobName + ' resume well. Now Status: ' + str(status)
                                        mail_content = 'Dear'  + '<p>' + 'The status of '+ webjobName + ' is ' + str(status) +'. Resume well.<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                        fsendmail( mailto_high,mail_subject,mail_content )

                            
                            sql_insert_1 = "insert into monitor_webjob(webjobName,status,cdatetime,othernote) values('%s','%s','%s',%d)"%(webjobName,status,hours_8hours_later,othernote)
                            cursor.execute(sql_insert_1)
                            cnxn.commit()




    cursor.close()