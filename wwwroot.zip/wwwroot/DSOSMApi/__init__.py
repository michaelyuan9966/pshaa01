import datetime
import logging
import azure.functions as func
import pyodbc
import subprocess
import re
import json
import sys
import os
import datetime
import requests
from datetime import timedelta
from ..mail.smailfunc import fsendamail
from ..mail.smailfunc import fsendmail


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)


    # m = Message(account=account,subject=mail_subject,body = HTMLBody(mail_content),to_recipients=mailto)
    # m.send()
    # mailto_high = ["chunbin.tang@bhp.com","leo.wang@bhp.com","binghua.wu@bhp.com","tianhong.zhao@bhp.com","charles.liu@bhp.com","MCCSupportTeam@bhpbilliton.com","gabriella.wu@bhp.com","DL-TECH-SHA-MCCDevOps@bhpbilliton.com"]
    # mailto_normal = ["leo.wang@bhp.com","binghua.wu@bhp.com","tianhong.zhao@bhp.com","charles.liu@bhp.com","MCCSupportTeam@bhpbilliton.com"]
    mailto_high = "chunbin.tang@bhp.com;leo.wang@bhp.com;binghua.wu@bhp.com;tianhong.zhao@bhp.com;charles.liu@bhp.com;MCCSupportTeam@bhpbilliton.com;gabriella.wu@bhp.com;DL-TECH-SHA-MCCDevOps@bhpbilliton.com"
    mailto_normal = "leo.wang@bhp.com;binghua.wu@bhp.com;tianhong.zhao@bhp.com;charles.liu@bhp.com;MCCSupportTeam@bhpbilliton.com"
    # mailto_high = "michael.yuan@bhp.com"
    # mailto_normal = "michael.yuan@bhp.com"

    server_sql = os.environ["server_sql"]
    database_sql = os.environ["database_sql"]
    username_sql = os.environ["username_sql"]
    password_sql = os.environ["password_sql"]
    driver_sql = os.environ["driver_sql"]
    
    url_token = "https://login.microsoftonline.com/4f6e1565-c2c7-43cb-8a4c-0981d022ce20/oauth2/token"
    client_id = "b7bbb52e-3990-4df5-b504-ab4dbd7da22c"
    client_secret = "SS96Aw1@gu:JUwRM0S.n[2uu?khK-yM9"
    grant_type = os.environ["grant_type"]
    resource = "https://BHPB.onmicrosoft.com/823e13f2-ab84-459b-8376-750fb6fdbc6f"
    payload_token = {"client_id":client_id,"client_secret":client_secret,"grant_type":grant_type,"resource":resource}

    try:
        cnxn = pyodbc.connect('DRIVER='+driver_sql+';SERVER='+server_sql+';PORT=1433;DATABASE='+database_sql+';UID='+username_sql+';PWD='+ password_sql)
        cursor = cnxn.cursor()
    except Exception as error_sql_con:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("DataBase_Connect Error: " + database_sql + "################" + str(error_sql_con) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]: DataBase_Connect Error: " + database_sql
        mail_content = 'Dear'  + '<p>' + 'The DataBase of '+ database_sql + ' could not be connected, please check.<br>Detail error: ' + str(error_sql_con) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
        sys.exit(1)

    try:
        response_token = requests.request("GET", url_token, data=payload_token)
        respone_token_text = response_token.text
        respone_token_tojson = json.loads(respone_token_text)
        response_token_r = respone_token_tojson["access_token"]
    except Exception as get_token_error:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("Get_Token Error: ################" + str(get_token_error) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]: Get_Token ERROR"
        mail_content = 'Dear'  + '<p>' + 'Get_Token erorr, please check.<br>Detail error: ' + str(get_token_error) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
        sys.exit(1)

    token_head_val = "Bearer "+ response_token_r
    headers = {'Authorization': token_head_val}

    try:
        #cursor.execute("select * from monitor_apiconfig where needcheck = 1")
        cursor.execute("select * from monitor_apiconfig where murl_name in ('OSM-Api-Pro') and needcheck = 1")
        tables = cursor.fetchall()
        for row in tables:
            if row is not None:
                logging.info("##############################")
                logging.info(row)
                murl_name = row[1]
                murl = row[2]
                last_api_result_dict = {}
                http_code_lastcheck = 200
                sql_lastcheck = "SELECT top(1) http_code,api_status,api_result FROM monitor_mapi where murl_name = " + murl_name +" order by id desc"
                try:
                    cursor.execute(sql_lastcheck)
                    table_lastcheck = cursor.fetchall()
                    for row_lastcheck in table_lastcheck:
                        if row_lastcheck is not None:
                            http_code_lastcheck = int(row_lastcheck[0])
                            api_result_lastcheck = row_lastcheck[2]
                            last_api_result_dict = json.loads(api_result_lastcheck)


                except Exception as last_sql_query_error:
                    logging.info(last_sql_query_error)
                    last_api_result_dict = {}

                try:
                    response = requests.request("GET", murl, headers=headers)
                    response_value = response.text
                    http_code = response.status_code
                    api_status = 1
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                
                except Exception as get_value_api_error:
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    logging.error("Request api result error:" + murl + "################" + str(get_value_api_error) + "################; Check Time: " + hours_8hours_later)

                    mail_subject = "[Critical]: Request api "+ murl + " result Error"
                    mail_content = 'Dear'  + '<p>' + 'Request api result error:' + murl + ', please check.<br>Detail error: ' + str(get_value_api_error) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )
                    sys.exit(1)


                if http_code != 200 and http_code != http_code_lastcheck:
                    api_status = -1
                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    mail_subject = '[Critical]' + murl_name + ' HTTP_CODE: ' + str(http_code)
                    mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' is ' + str(http_code) +'. Please check it.<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( mailto_high,mail_subject,mail_content )


                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,cdatetime) values('%s',%d,%d,'%s')"%(murl_name,http_code,api_status,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()




                        
                if http_code == 200 and http_code != http_code_lastcheck:
                    api_status = 1
                    mail_subject = '[Critical]Resume: ' + murl_name + ' resume well. Now HTTP_CODE: ' + str(http_code)
                    mail_content = 'Dear'  + '<p>' + 'The status of '+ murl + ' HTTP_CODE is ' + str(http_code) +'. Resume well.<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                    fsendmail( mailto_high,mail_subject,mail_content )

                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,api_result,cdatetime) values('%s',%d,%d,'%s','%s')"%(murl_name,http_code,api_status,response_value,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()




                if http_code == 200 and http_code_lastcheck == 200:
                    try:
                        response_value_dict = json.loads(response_value)
                        last_status_message = last_api_result_dict['message']
                        curr_status_message = response_value_dict['message']                    
                        if last_status_message == curr_status_message:
                            if curr_status_message != 'Success':
                                mail_subject = '[Middle]'+ murl_name + ' Status: ' + curr_status_message
                                mail_content = 'Dear  all'  + '<p>' + 'The status of '+ murl + ' is ' + curr_status_message +'. Please check it.<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                fsendmail( mailto_normal,mail_subject,mail_content )
                        else:
                            if curr_status_message != 'Success':
                                mail_subject = '[Middle]'+ murl_name + ' Status: ' + curr_status_message
                                mail_content = 'Dear  all'  + '<p>' + 'The status of '+ murl + ' is ' + curr_status_message +'. Please check it.<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                fsendmail( mailto_normal,mail_subject,mail_content )
                            else:
                                mail_subject = '[Middle]Resume'+ murl_name + ' Status: ' + curr_status_message
                                mail_content = 'Dear  all'  + '<p>' + 'The status of '+ murl + ' is ' + curr_status_message +'. It was resumed.<br>Check_Time :'+ hours_8hours_later + '<br><br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
                                fsendmail( mailto_normal,mail_subject,mail_content )
                    
                    except Exception as get_last_status_error:
                        logging.info(get_last_status_error)


                    hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
                    sql_insert = "insert into monitor_mapi(murl_name,http_code,api_status,api_result,cdatetime) values('%s',%d,%d,'%s','%s')"%(murl_name,http_code,api_status,response_value,hours_8hours_later)
                    logging.info(sql_insert)
                    cursor.execute(sql_insert)
                    cursor.commit()


    except Exception as select_table_eror:
        hours_8hours_later = (datetime.datetime.now() + timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S")
        logging.error("Select table Error: monitor_apiconfig################" + str(select_table_eror) + "################; Check Time: " + hours_8hours_later)

        mail_subject = "[Critical]:Select table Error: monitor_apiconfig"
        mail_content = 'Dear'  + '<p>' + 'Select table Error: monitor_apiconfig################, please check.<br>Detail error: ' + str(select_table_eror) + '<br>Check_Time :'+ hours_8hours_later + '<br>  <br><font size=4 color=red><b>Notes:</b></font><br>This is a system generated email, please do not reply.<br><br> <b>MCC Release and Support Team</b>'
        fsendmail( "michael.yuan@bhp.com",mail_subject,mail_content )

        sys.exit(1)

    cnxn.close()